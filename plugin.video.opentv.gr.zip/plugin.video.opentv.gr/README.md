
OPENTV Player addon for Kodi
======================

About
-----
OPENTV live and on-demand broadcasts

Kodi Addon for http://www.tvopen.gr

This addon is not published nor endorsed by tvopen.gr

This addon offers content available in Greece


Artwork
---------------------
Artwork sourced from public domains:

https://www.tvopen.gr/sites/all/themes/etv/images/openlogo.svg

http://www.iconarchive.com/show/windows-8-icons-by-icons8.html


License
-------
This software is released under the [GPL 3.0 license] [1].

[1]: http://www.gnu.org/licenses/gpl-3.0.html