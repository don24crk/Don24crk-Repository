import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import urllib.request
import urllib.parse
import re
import sys

addon = xbmcaddon.Addon()
addon_url = sys.argv[0]
addon_handle = int(sys.argv[1])

M3U_URL = "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/TurkTV.m3u"

def get_m3u_playlist(url):
    try:
        req = urllib.request.Request(
            url, 
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        )
        with urllib.request.urlopen(req) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        xbmc.log(f"AliveTR Error fetching playlist: {e}", xbmc.LOGERROR)
        return ""

def parse_m3u(data):
    channels = []
    lines = data.splitlines()
    current_item = {}
    
    for line in lines:
        line = line.strip()
        if line.startswith('#EXTINF:'):
            current_item = {}
            tvg_logo = re.search(r'tvg-logo="(.*?)"', line)
            if tvg_logo:
                current_item['logo'] = tvg_logo.group(1)
            else:
                current_item['logo'] = ''
                
            match_title = re.search(r',(.+)$', line)
            if match_title:
                current_item['title'] = match_title.group(1)
            else:
                current_item['title'] = 'Unknown Channel'
                
        elif line and not line.startswith('#'):
            current_item['url'] = line
            channels.append(current_item)
            
    return channels

def list_channels():
    xbmcplugin.setContent(addon_handle, 'videos')
    playlist_data = get_m3u_playlist(M3U_URL)
    channels = parse_m3u(playlist_data)
    
    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['title'])
        list_item.setArt({'icon': channel['logo'], 'thumb': channel['logo']})
        list_item.setProperty('IsPlayable', 'true')
        
        url = f"{addon_url}?action=play&url={urllib.parse.quote_plus(channel['url'])}"
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(addon_handle)

def play_channel(url):
    list_item = xbmcgui.ListItem(path=url)
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    xbmcplugin.setResolvedUrl(addon_handle, True, list_item)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring[1:]))
    action = params.get('action')
    
    if action == 'play':
        play_channel(params['url'])
    else:
        list_channels()

if __name__ == '__main__':
    router(sys.argv[2])