import sys
import os
import json
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Addon Konstanten
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else 0
ADDON_BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
FAV_FILE = os.path.join(PROFILE_DIR, 'favorites.json')

# Spezifischer User-Agent aus Vorgabe
USER_AGENT = "Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.187 Mobile Safari/537.36 EdgA/150.0.4078.96"

# M3U Quellen (Hier deine echten M3U-URLs eintragen)
M3U_SOURCES = {
    "greektv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "italiantv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/it.m3u",
    "francetv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/fr.m3u",
    "polskytv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/pl.m3u",
    "spanischtv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/es.m3u",
    "turktv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/TurkTV.m3u",
    "germantv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/ger.m3u",
    "usatv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/us.m3u",
    "indiatv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/in.m3u",
}

# Profilverzeichnis erstellen falls nicht vorhanden
if not xbmcvfs.exists(PROFILE_DIR):
    xbmcvfs.mkdir(PROFILE_DIR)

def get_favorites():
    if xbmcvfs.exists(FAV_FILE):
        try:
            with open(FAV_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return []
    return []

def save_favorites(favs):
    try:
        with open(FAV_FILE, 'w', encoding='utf-8') as f:
            json.dump(favs, f, indent=4)
    except Exception as e:
        xbmc.log(f"BarneyStinson Error: {str(e)}", xbmc.LOGERROR)

def build_url(query):
    return ADDON_BASE_URL + '?' + urllib.parse.urlencode(query)

def show_main_menu():
    add_directory_item("⭐ Favoriten", build_url({'mode': 'show_favorites'}), is_folder=True)
    for country in M3U_SOURCES.keys():
        url = build_url({'mode': 'show_channels', 'country': country})
        add_directory_item(f"📺 {country}", url, is_folder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def add_directory_item(name, url, is_folder=False, icon='', fanart='', context_menu=None):
    icon = icon if icon else ADDON.getAddonInfo('icon')
    fanart = fanart if fanart else ADDON.getAddonInfo('fanart')
    
    li = xbmcgui.ListItem(name)
    li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
    
    if context_menu:
        li.addContextMenuItems(context_menu)
    if not is_folder:
        li.setProperty('IsPlayable', 'true')
        
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=is_folder)

def get_youtube_playable_url(url):
    """Prüft und konvertiert M3U-URLs basierend auf deiner Vorgabe"""
    url_lower = url.lower()
    
    # Exakt geforderte Prüfung für direkte YouTube-Plugin-Links
    if 'plugin://plugin.video.youtube' in url_lower:
        return url
        
    # Dynamischer Fallback für unformatierte Web-Links aus Standard-M3Us
    elif "youtube.com" in url_lower or "youtu.be" in url_lower:
        video_id = ""
        if "youtu.be" in url_lower:
            match = re.search(r'youtu\.be/([^?&]+)', url)
            if match:
                video_id = match.group(1)
        else:
            match = re.search(r'[?&]v=([^&]+)', url)
            if match:
                video_id = match.group(1)
        
        if video_id:
            return f"plugin://plugin.video.youtube/play/?video_id={video_id}"
            
    return url

def parse_m3u(country):
    url = M3U_SOURCES.get(country)
    channels = []
    if not url or url.startswith("https://example.com"):
        return channels

    try:
        req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as response:
            content = response.read().decode('utf-8', errors='ignore')
            
        lines = content.splitlines()
        current_name = ""
        current_logo = ""
        
        for line in lines:
            line = line.strip()
            if line.startswith("#EXTINF:"):
                logo_match = re.search(r'tvg-logo="([^"]*)"', line, re.IGNORECASE)
                current_logo = logo_match.group(1) if logo_match else ""
                
                name_split = line.split(',', 1)
                current_name = name_split[1].strip() if len(name_split) > 1 else "Unbekannter Sender"
                
            elif line.startswith("http") or line.startswith("plugin://"):
                if current_name:
                    clean_url = line.replace('\r', '').strip()
                    final_url = get_youtube_playable_url(clean_url)
                    
                    channels.append({
                        'name': current_name,
                        'url': final_url,
                        'logo': current_logo,
                        'country': country
                    })
                    current_name = ""
                    current_logo = ""
    except Exception as e:
        xbmc.log(f"BarneyStinson M3U Error ({country}): {str(e)}", xbmc.LOGERROR)
    return channels

def show_channels(country):
    channels = parse_m3u(country)
    
    if not channels:
        add_directory_item("⚠️ Keine Sender in dieser Liste gefunden", build_url({'mode': 'none'}), is_folder=False)
    else:
        for ch in channels:
            enc_url = urllib.parse.quote_plus(ch['url'])
            enc_name = urllib.parse.quote_plus(ch['name'])
            enc_logo = urllib.parse.quote_plus(ch['logo'])
            
            play_url = build_url({'mode': 'play', 'url': ch['url']})
            cm = [('Zu Favoriten hinzufügen', f'RunPlugin({build_url({"mode": "add_fav", "name": enc_name, "url": enc_url, "logo": enc_logo})})')]
            
            add_directory_item(ch['name'], play_url, is_folder=False, icon=ch['logo'], context_menu=cm)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def show_favorites():
    favs = get_favorites()
    if not favs:
        add_directory_item("Keine Favoriten gespeichert", build_url({'mode': 'none'}), is_folder=False)
    else:
        for fav in favs:
            enc_url = urllib.parse.quote_plus(fav['url'])
            enc_name = urllib.parse.quote_plus(fav['name'])
            enc_logo = urllib.parse.quote_plus(fav['logo'])
            
            play_url = build_url({'mode': 'play', 'url': fav['url']})
            cm = [('Aus Favoriten entfernen', f'RunPlugin({build_url({"mode": "remove_fav", "name": enc_name})})')]
            
            add_directory_item(fav['name'], play_url, is_folder=False, icon=fav['logo'], context_menu=cm)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_stream(stream_url):
    li = xbmcgui.ListItem(path=stream_url)
    
    # Direktes Auflösen für YouTube-Plugin-Links über setResolvedUrl
    if "plugin://plugin.video.youtube/" in stream_url:
        li.setPath(stream_url)
    
    # InputStream.Adaptive Integration für .mpd und .m3u8 (HLS)
    elif ".mpd" in stream_url.lower() or ".m3u8" in stream_url.lower():
        li.setProperty('inputstream', 'inputstream.adaptive')
        if ".mpd" in stream_url.lower():
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            li.setMimeType('application/xml+dash')
        else:
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            li.setMimeType('application/vnd.apple.mpegurl')
            
        li.setProperty('inputstream.adaptive.stream_headers', f'User-Agent={urllib.parse.quote_plus(USER_AGENT)}')

    # Standard HTTP-Streams erhalten den VLC-Option User-Agent via Pipe angehängt
    else:
        if "|" not in stream_url:
            stream_url += f"|User-Agent={urllib.parse.quote_plus(USER_AGENT)}"
            li.setPath(stream_url)

    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)

# Router: Absolut kodi-konformes Parsing über sys.argv[2]
query_string = sys.argv[2] if len(sys.argv) > 2 else ""
params = dict(urllib.parse.parse_qsl(query_string.lstrip('?'))) if query_string else {}
mode = params.get('mode')

if mode is None:
    show_main_menu()
elif mode == 'show_channels':
    show_channels(params.get('country'))
elif mode == 'show_favorites':
    show_favorites()
elif mode == 'play':
    play_stream(params.get('url'))
elif mode == 'add_fav':
    favs = get_favorites()
    name = urllib.parse.unquote_plus(params.get('name'))
    url = urllib.parse.unquote_plus(params.get('url'))
    logo = urllib.parse.unquote_plus(params.get('logo'))
    
    if not any(f['name'] == name for f in favs):
        favs.append({'name': name, 'url': url, 'logo': logo})
        save_favorites(favs)
        xbmcgui.Dialog().notification('Barney Stinson', f'{name} hinzugefügt!', xbmcgui.NOTIFICATION_INFO, 2000)
elif mode == 'remove_fav':
    favs = get_favorites()
    name = urllib.parse.unquote_plus(params.get('name'))
    favs = [f for f in favs if f['name'] != name]
    save_favorites(favs)
    xbmcgui.Dialog().notification('Barney Stinson', f'{name} entfernt!', xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin('Container.Refresh')
