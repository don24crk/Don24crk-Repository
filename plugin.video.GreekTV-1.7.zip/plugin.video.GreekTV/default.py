import sys
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Addon-Instanzen initialisieren
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

# Standard-User-Agent für HTTP-Anfragen & Playlisten
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"

# Playlist-M3U-Quellen
M3U_SOURCES = {
    "LiveTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "Supermami": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SUPERMAMMI.m3u",
    "Jesusmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/JESUSMOVIES.m3u",
    "Kidsmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/KIDSMOVIES.m3u",
    "Greekmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/GreekMovies.m3u",
    "AlikiVougiouklaki Tenies": "https://example.com",  # Placeholder URL
}

def get_param(params, key, default=None):
    """ Hilfsfunktion: Holt einen Parameter sicher als String aus dem Kodi-Query """
    val = params.get(key, [None])[0]
    return urllib.parse.unquote_plus(val) if val else default

def fetch_m3u(url):
    """ Holt die M3U-Playlist ab und fängt 404/Client-Fehler ab """
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return response.read().decode('utf-8', errors='ignore')
    except urllib.error.HTTPError as e:
        xbmc.log(f"[GreekTV] HTTP Error {e.code} beim Laden von: {url}", xbmc.LOGERROR)
        return ""
    except Exception as e:
        xbmc.log(f"[GreekTV] Netzwerkfehler: {str(e)}", xbmc.LOGERROR)
        return ""

def parse_m3u(content):
    """ Parst M3U Einträge inklusive TVG-Logo, Fanart, VLCOPT und YouTube Links """
    playlist_items = []
    if not content:
        return playlist_items

    logo_regex = re.compile(r'tvg-logo="([^"]+)"', re.IGNORECASE)
    fanart_regex = re.compile(r'fanart-image="([^"]+)"', re.IGNORECASE)
    
    current_item = {}
    
    for line in content.splitlines():
        line = line.strip()
        if not line:
            continue
            
        if line.startswith("#EXTINF:"):
            current_item = {}
            name_parts = line.split(',')
            current_item['name'] = name_parts[-1].strip() if name_parts else "Unknown Stream"
            
            logo = logo_regex.search(line)
            fanart = fanart_regex.search(line)
            
            current_item['logo'] = logo.group(1) if logo else ""
            current_item['fanart'] = fanart.group(1) if fanart else ""
            current_item['user_agent'] = USER_AGENT
            
        elif line.startswith("#EXTVLCOPT:http-user-agent="):
            ua_match = line.split("http-user-agent=")[-1].strip()
            if ua_match:
                current_item['user_agent'] = ua_match
            
        elif line.startswith("#") and not line.startswith("#EXT"):
            continue
        elif not line.startswith("#"):
            if current_item.get('name'):
                current_item['url'] = line.strip()
                playlist_items.append(current_item)
                current_item = {}
                
    return playlist_items

def show_categories():
    """ Zeigt die Hauptkategorien im Kodi-Addon an """
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "GreekTV - Κατηγορίες")
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    
    for category in M3U_SOURCES.keys():
        list_item = xbmcgui.ListItem(label=category)
        list_item.setInfo('video', {'title': category, 'plot': f"Streams für {category}"})
        list_item.setArt({'icon': 'https://img.samsungapps.com/productNew/000008070827/ENG/IconImage_20260727041347081_NEW_WAP_ICON_512_512.png', 'fanart': 'https://wallpapers4screen.com/Uploads/19-7-2022/40083/thumb2-4k-greece-flag-stone-texture-flag-of-greece-stone-background.jpg'}) 
        
        query = {'action': 'list_category', 'category': category}
        url = f"{BASE_URL}?{urllib.parse.urlencode(query, quote_via=urllib.parse.quote_plus)}"
        
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_category(category_name):
    """ Listet alle Streams innerhalb einer gewählten M3U-Kategorie auf """
    xbmcplugin.setPluginCategory(ADDON_HANDLE, category_name)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    
    m3u_url = M3U_SOURCES.get(category_name)
    if not m3u_url:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, False)
        return
        
    content = fetch_m3u(m3u_url)
    items = parse_m3u(content)
    
    for item in items:
        list_item = xbmcgui.ListItem(label=item['name'])
        
        art = {}
        if item['logo']: art['thumb'] = item['logo']
        if item['fanart']: art['fanart'] = item['fanart']
        list_item.setArt(art)
        
        # RESUME FIX: Weist Kodi an, Lesezeichen lokal für diesen Titel zu verwalten
        list_item.setInfo('video', {
            'title': item['name'],
            'mediatype': 'movie',  
            'code': item['name']   
        })
        list_item.setProperty('IsPlayable', 'true')
        
        query = {
            'action': 'play',
            'url': item['url'],
            'title': item['name'],
            'ua': item.get('user_agent', USER_AGENT)
        }
        url = f"{BASE_URL}?{urllib.parse.urlencode(query, quote_via=urllib.parse.quote_plus)}"
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_stream(stream_url, title, user_agent):
    """ Spielt den Stream ab, regelt YouTube-PlugIn-Verweise und korrigiert archive.org-Header """
    # SPRECHENDER STRING FIX: Holt das nullte Element [0] aus der Liste extrahiert
    clean_url = stream_url.split('|')[0] if "|" in stream_url else stream_url
    
    list_item = xbmcgui.ListItem(label=title)
    
    # MAXIMUM ARCHIVE.ORG PLAYBACK FIX
    if "archive.org" in clean_url:
        headers = [
            f"User-Agent={urllib.parse.quote(user_agent)}",
            f"Referer={urllib.parse.quote('https://archive.org')}",
            f"Accept-Encoding={urllib.parse.quote('identity')}",
            "disablehttp2=true"
        ]
        final_url = f"{clean_url}|{'&'.join(headers)}"
    else:
        final_url = clean_url

    # YouTube-Plugin Weiterleitung
    yt_match = re.search(r'(?:youtube\.com/(?:watch\?v=|embed/)|youtu\.be/)([a-zA-Z0-9_-]{11})', final_url)
    if yt_match:
        video_id = yt_match.group(1)
        youtube_plugin_url = f"plugin://plugin.video.youtube/play/?video_id={video_id}"
        list_item.setPath(youtube_plugin_url)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)
        return

    # InputStream.Adaptive Aktivierung für echte adaptive Video-Streams (.mpd oder .m3u8)
    if ".mpd" in final_url or ".m3u8" in final_url:
        try:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper("mpd" if ".mpd" in final_url else "hls")
            if is_helper.check_inputstream():
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd' if '.mpd' in final_url else 'hls')
                list_item.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={urllib.parse.quote(user_agent)}")
        except ImportError:
            xbmc.log("[GreekTV] inputstreamhelper Modul nicht gefunden.", xbmc.LOGWARNING)

    # RESUME FIX II: Weist die finale Streaming-URL zu und spiegelt die Lesezeichen-Metadaten
    list_item.setPath(final_url)
    list_item.setInfo('video', {
        'title': title,
        'mediatype': 'movie'
    })

    # Signalisiert Kodi, dass der Pfad erfolgreich gelöst wurde
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)

def main():
    """ Router-Logik für Kodi Parameter-Übergabe """
    raw_params = sys.argv[2].lstrip('?') if len(sys.argv) > 2 else ""
    params = urllib.parse.parse_qs(raw_params)
    
    action = get_param(params, 'action')
    
    if action is None:
        show_categories()
    elif action == 'list_category':
        category = get_param(params, 'category')
        list_category(category)
    elif action == 'play':
        url = get_param(params, 'url')
        title = get_param(params, 'title', '')
        ua = get_param(params, 'ua', USER_AGENT)
        play_stream(url, title, ua)

if __name__ == '__main__':
    main()
