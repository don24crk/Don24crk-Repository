import sys
import re
import urllib.parse
import urllib.request
import urllib.error
import xbmcgui
import xbmcplugin
import xbmcaddon

# Korrekte Handhabung der System-Argumente für Kodi
BASE_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()

# Globaler, unauffälliger User-Agent zur Vermeidung von 403/404 Sperren
USER_AGENT = "Mozilla/5.0 (Linux; Android 10; ONEPLUS A6003) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.187 Mobile Safari/537.36 EdgA/150.0.4078.96"

# DEINE PLAYLISTS (Ersetze die Platzhalter mit deinen echten M3U-Links)
PLAYLISTS = {
    "Greektv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "Supermami": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SUPERMAMMI.m3u",
    "Jesusmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/JESUSMOVIES.m3u",
    "Kidsmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/KIDSMOVIES.m3u",
    "AlikiVougiouklaki Tenies": "https://example.com"
}

def fetch_m3u_data(url_or_path):
    """Lädt die M3U-Daten herunter oder liest sie lokal mit robustem Error-Handling."""
    if not url_or_path.startswith(("http://", "https://")):
        try:
            with open(url_or_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception as e:
            show_notification("Lokaler Fehler", f"Datei nicht lesbar: {str(e)}")
            return ""

    # Erweiterte Header, um Botsperren (403/404) zu umgehen
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': '*/*',
        'Accept-Language': 'el-GR,el;q=0.9,en-US;q=0.8,en;q=0.7'
    }
    
    req = urllib.request.Request(url_or_path, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=15) as response:
            return response.read().decode('utf-8', errors='ignore')
    except urllib.error.HTTPError as e:
        show_notification("Server Fehler", f"HTTP {e.code} bei Playlist-Abruf")
    except urllib.error.URLError as e:
        show_notification("Netzwerk Fehler", f"Server nicht erreichbar: {str(e.reason)}")
    except Exception as e:
        show_notification("Fehler", f"Unerwarteter Fehler: {str(e)}")
    return ""

def show_notification(title, message):
    """Zeigt eine saubere GUI-Benachrichtigung in Kodi an."""
    xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_ERROR, 5000)

def parse_m3u(data):
    """Parst M3U-Einträge mittels flexibler Regex für alle Anführungszeichen."""
    channels = []
    lines = data.splitlines()
    current_item = {}

    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        if line.startswith("#EXTINF:"):
            current_item = {}
            # Regex matcht nun sowohl "wert" als auch 'wert'
            tvg_id = re.search(r'tvg-id=["\']([^"\']+)["\']', line)
            tvg_logo = re.search(r'tvg-logo=["\']([^"\']+)["\']', line)
            fanart = re.search(r'fanart-image=["\']([^"\']+)["\']', line)
            
            # Holt den Sendernamen nach dem letzten Komma
            name_parts = line.split(',')
            name_match = name_parts[-1].strip() if name_parts else "Unbekannter Sender"
            
            current_item['name'] = name_match
            current_item['tvg_id'] = tvg_id.group(1) if tvg_id else ""
            current_item['logo'] = tvg_logo.group(1) if tvg_logo else ""
            current_item['fanart'] = fanart.group(1) if fanart else ""
            
        elif line.startswith("#EXTVLCOPT:"):
            ua_match = re.search(r'http-user-agent=([^\s]+)', line)
            if ua_match:
                current_item['ua'] = ua_match.group(1)
            continue
            
        elif not line.startswith("#"):
            if current_item:
                current_item['url'] = line
                if 'ua' not in current_item:
                    current_item['ua'] = USER_AGENT
                channels.append(current_item)
                current_item = {}
                
    return channels

def show_categories():
    """Erstellt das Hauptmenü-Verzeichnis."""
    xbmcplugin.setPluginCategory(ADDON_HANDLE, "GreekTV")
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')

    for category in PLAYLISTS.keys():
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({
            'icon': ADDON.getAddonInfo('icon'),
            'fanart': ADDON.getAddonInfo('fanart')
        })
        
        url = f"{BASE_URL}?action=list_category&category={urllib.parse.quote_plus(category)}"
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_category_channels(category_name):
    """Listet die Kanäle der gewählten M3U-Kategorie auf."""
    xbmcplugin.setPluginCategory(ADDON_HANDLE, category_name)
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')

    playlist_url = PLAYLISTS.get(category_name)
    if not playlist_url:
        show_notification("Fehler", "Ungültige Kategorie gewählt.")
        return

    m3u_content = fetch_m3u_data(playlist_url)
    if not m3u_content:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)
        return

    channels = parse_m3u(m3u_content)
    
    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['name'])
        
        # Grafiken zuweisen
        list_item.setArt({
            'thumb': channel['logo'] if channel['logo'] else ADDON.getAddonInfo('icon'),
            'icon': channel['logo'] if channel['logo'] else ADDON.getAddonInfo('icon'),
            'fanart': channel['fanart'] if channel['fanart'] else ADDON.getAddonInfo('fanart')
        })
        
        # Neues Kodi 21/22 Info-Tag-System (Python 3.12 konform)
        video_info = list_item.getVideoInfoTag()
        video_info.setTitle(channel['name'])
        if channel['tvg_id']:
            video_info.setPlot(f"EPG / TVG ID: {channel['tvg_id']}")
        
        # Parameter codieren
        enc_url = urllib.parse.quote_plus(channel['url'])
        enc_ua = urllib.parse.quote_plus(channel['ua'])
        url = f"{BASE_URL}?action=play&url={enc_url}&ua={enc_ua}"
        
        list_item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_stream(stream_url, custom_ua):
    """Wiedergabe-Logik mit YouTube-Routing und InputStream-Konfiguration."""
    list_item = xbmcgui.ListItem(path=stream_url)
    ua_to_use = custom_ua if custom_ua else USER_AGENT

    # YouTube Integration (Unterstützt Standard, Shorts und Plugin-Syntax)
    if "youtube.com" in stream_url or "youtu.be" in stream_url or stream_url.startswith("youtube://"):
        video_id = ""
        if "youtube://video/" in stream_url:
            video_id = stream_url.split("youtube://video/")[-1]
        else:
            # Erweiterte Regex für alle YouTube-Formate inklusive /shorts/
            match = re.search(r'(?:v=|\/v\/|youtu\.be\/|\/embed\/|\/shorts\/)([^#\&\?]+)', stream_url)
            if match:
                video_id = match.group(1)
                
        if video_id:
            youtube_plugin_url = f"plugin://plugin.video.youtube/play/?video_id={video_id}"
            list_item.setPath(youtube_plugin_url)
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)
            return

    # Adaptive Streaming Erkennung (.mpd & .m3u8)
    if ".mpd" in stream_url or ".m3u8" in stream_url:
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        
        if ".mpd" in stream_url:
            list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        else:
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
        # User-Agent Syntax an die Stream-URL für Kodi anhängen
        stream_url += f"|User-Agent={urllib.parse.quote_plus(ua_to_use)}"
        list_item.setPath(stream_url)
    else:
        # Fallback für normale HTTP/TS Videostreams
        stream_url += f"|User-Agent={urllib.parse.quote_plus(ua_to_use)}"
        list_item.setPath(stream_url)

    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)

def main():
    """Zentraler Pfad-Router."""
    # Extrahiert Parameter aus sys.argv[2]
    param_string = sys.argv[2] if len(sys.argv) >= 3 else ''
    params = dict(urllib.parse.parse_qsl(param_string.lstrip('?')))
    action = params.get('action')
    
    if not action:
        show_categories()
    elif action == 'list_category':
        list_category_channels(urllib.parse.unquote_plus(params.get('category')))
    elif action == 'play':
        url = urllib.parse.unquote_plus(params.get('url'))
        ua = urllib.parse.unquote_plus(params.get('ua', ''))
        play_stream(url, ua)

if __name__ == '__main__':
    main()
