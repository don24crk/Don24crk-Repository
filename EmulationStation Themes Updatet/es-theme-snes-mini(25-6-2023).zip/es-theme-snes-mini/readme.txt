Theme designed by Ruckage
Version 1.10
30/09/2018

Theme based on and inspired by the look of the menus used on the SNES Classic.
------------------------------------------------------------------------------

License

This theme is being actively developed, a great deal of work has been put into the theme and art so please do not use the graphics I have created in other projects.

You are free to modify the theme for your personal use only - please do not share modified versions of this theme.

Commercial distribution is prohibited

If in doubt please ask in the dedictated topic at the retropie forum: https://retropie.org.uk/forum/topic/12583/snes-mini-theme

-------------------------------------------------------------------------------  

Currently this theme supports:

NES
Atari 2600
Atari 5200
Atari 7800
Commodore 64
Gameboy
Gameboy Color
Intellivision
Sega Game Gear
Sega Master System
PC Engine
TurboGrafx 16
ZX Spectrum
Retropie setup menu
Famicom
Gameboy Advance
Super Nintendo
Neo Geo
Megadrive
Genesis
Colecovision
Vectrex
Super Famicom
MAME
NeoGeo Pocket
NeoGeo Pocket Color
Family Computer Disk System
Playstation
Wonderswan
Wonderswan Color
Final Burn Alpha
Nintendo 64
Sega Cd
Odyssey 2
Nintendo DS
Arcade
Daphne
PSP
SG-1000
Atari Lynx
Ports
Virtual Boy
auto-favorites
auto-lastplayed
auto-allgames
Dreamcast
Sega 32x
Amiga
MSX
MSX2
Game and watch
PC Engine CD
PC
Snes-Classic
Nes-Classic
Famicom-classic
Super Famicom-classic

30/09/2018
Nes mini theme is now incorporated into this theme. New layout added with no meta data at all - just the game list (no_meta_g).

03/12/2017
Added several new options to the config file (font size and text alignment).  Added support for multiple resolutions including 4x3 resoloutions, ntsc, and pal.  Added 6 new no-meta layouts.   Adjusted the USA border to allow more space for the help icons. Updated the pc-engine icon.  Changed the colour of the usa dreamcast logo.

18/10/17
Added Amiga, MSX, MSX2, Game and watch, PC Engine CD, PC, Snes-Classic, Nes-Classic, Famicom-classic,  and Super Famicom-classic. Changed theme to allow for multiple custom setups. Various other fixes.

03/10/17
Custom collections are now supported. Changing region style to USA will now automagically change the icon and logo from Megadrive to Genesis. Fixed an error with blurred_shots_dark.xml.

29/09/2017
Changing region style to USA will now automagically change the icon, logo, and background for the SNES to the USA style. Removed missing.png as it was sometimes visible behind boxart etc. Updated the help images for USA style as the button colours were reversed.

28/09/17
Changed help buttons to correctly match ES functions. Added option to switch between icon/text for number of players. Fixed naming error with nds icon.  Changed ${system.name} to ${system.theme} as advised by @jdrassa.  

26/09/2017
Initial release
