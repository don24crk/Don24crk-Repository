# -*- coding: utf-8 -*-

# GreekTV Addon
# Author don24crk
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

from __future__ import absolute_import
from resources.lib import router

router.route()
