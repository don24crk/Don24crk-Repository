import sys
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Addon-Initialisierung
ADDON = xbmcaddon.Addon()

# Kodi übergibt sys.argv als Liste von Strings: [0]=BaseURL, [1]=Handle, [2]=Query
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1

# Kategorien und dazugehörige M3U-Playlists
PLAYLISTS = {
    "LiveTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "Supermammi": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SUPERMAMMI.m3u",
    "Jesusmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/JESUSMOVIES.m3u",
    "Kidsmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/KIDSMOVIES.m3u",
    "Greekmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/GreekMovies.m3u",
    "Seflix": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SEFLIX.m3u",
    "AlikiVougiouklaki Tenies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/AlikiVougioklakiTenies.m3u",
}

DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0"

# GRIECHISCHE PROXY-KONFIGURATION (Bypass für ERT1/ERT2)
GREEK_PROXY = "http://46.12.17.24:8080" 
USE_PROXY_FOR_ERT = True

def build_url(query):
    """ Erstellt eine Kodi-konforme Addon-URL aus einem Dictionary """
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def fetch_m3u(url):
    """ Lädt die M3U-Playlist und erzwingt UTF-8 Dekodierung """
    try:
        req = urllib.request.Request(url, headers={'User-Agent': DEFAULT_UA})
        with urllib.request.urlopen(req, timeout=12) as response:
            return response.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as e:
        xbmc.log(f"[GreekTV] HTTP Fehler {e.code} für URL: {url}", xbmc.LOGERROR)
        if e.code == 404:
            xbmcgui.Dialog().notification("Fehler", "Playlist nicht gefunden (404)", xbmcgui.NOTIFICATION_ERROR, 4000)
        return ""
    except Exception as e:
        xbmc.log(f"[GreekTV] Fehler beim Laden der Playlist: {str(e)}", xbmc.LOGERROR)
        return ""

def parse_m3u(content):
    """ Parst M3U-Inhalte und extrahiert Metadaten, URLs sowie KODIPROP-Eigenschaften """
    playlist_items = []
    if not content:
        return playlist_items

    lines = content.splitlines()
    current_item = {}
    current_props = {}

    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        if line.startswith("#EXTINF:"):
            current_item = {}
            current_props = {}  # Eigenschaften für diesen spezifischen Kanal zurücksetzen
            
            # Extrahiere den Sendernamen nach dem letzten Komma
            name_match = re.search(r',([^,]*)$', line)
            current_item["name"] = name_match.group(1).strip() if name_match else "Unbekannter Sender"
            
            # Extrahiere tvg-logo und fanart-image
            logo_match = re.search(r'tvg-logo="([^"]+)"', line)
            current_item["logo"] = logo_match.group(1) if logo_match else ""
            fanart_match = re.search(r'fanart-image="([^"]+)"', line)
            current_item["fanart"] = fanart_match.group(1) if fanart_match else ""
            
        elif line.startswith("#KODIPROP:"):
            # Extrahiere Schlüssel-Wert-Paare aus den Kodi-Properties
            prop_match = re.match(r'#KODIPROP:\s*([^=]+)=(.*)', line)
            if prop_match:
                key = prop_match.group(1).strip()
                val = prop_match.group(2).strip()
                current_props[key] = val
                
        elif line.startswith(("http://", "https://", "rtmp://", "p2p://")) or line.lower().endswith(".strm") or "archive.org" in line.lower():
            if current_item and "name" in current_item:
                stream_url = line
                if "archive.org/details/" in stream_url.lower():
                    stream_url = stream_url.replace("/details/", "/download/")
                
                current_item["url"] = stream_url
                # Speichere die gesammelten Properties im Kanal-Objekt ab
                current_item["props"] = current_props.copy()
                
                playlist_items.append(current_item)
                current_item = {}
                current_props = {}
                
    return playlist_items

def show_categories():
    """ Zeigt die Hauptkategorien im Kodi-Addon an """
    for category in PLAYLISTS.keys():
        url = build_url({"action": "list_channels", "category": category})
        li = xbmcgui.ListItem(label=category)
        li.setArt({'icon': 'https://img.samsungapps.com/productNew/000008070827/ENG/IconImage_20260727041347081_NEW_WAP_ICON_512_512.png', 'fanart': 'https://wallpapers4screen.com/Uploads/19-7-2022/40083/thumb2-4k-greece-flag-stone-texture-flag-of-greece-stone-background.jpg'})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def show_channels(category):
    """ Lädt die M3U und baut die Kanalliste inklusive versteckter DRM-Parameter auf """
    m3u_url = PLAYLISTS.get(category)
    if not m3u_url:
        return
        
    m3u_content = fetch_m3u(m3u_url)
    channels = parse_m3u(m3u_content)
    
    if not channels:
        xbmcgui.Dialog().notification("Info", "Keine Einträge gefunden", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    if category.lower() == "livetv":
        xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    else:
        xbmcplugin.setContent(ADDON_HANDLE, 'movies')

    for channel in channels:
        stream_url = channel["url"]
        li = xbmcgui.ListItem(label=channel["name"])
        
        art_dict = {
            "thumb": channel["logo"] if channel["logo"] else "DefaultVideo.png",
            "icon": channel["logo"] if channel["logo"] else "DefaultVideo.png",
            "poster": channel["logo"] if channel["logo"] else "DefaultVideo.png",
            "fanart": channel["fanart"] if channel["fanart"] else "DefaultFanart.png"
        }
        li.setArt(art_dict)
        li.setProperty('IsPlayable', 'true')
        
        info_labels = {'title': channel["name"]}
        if category.lower() != "livetv":
            info_labels['mediatype'] = 'movie'
        li.setInfo('video', info_labels)
        
        # Übermittle die ausgelesenen Properties via URL-Query an die Abspielfunktion
        query = {"action": "play", "url": stream_url}
        if "props" in channel and channel["props"]:
            query["props"] = urllib.parse.urlencode(channel["props"])
            
        play_url = build_url(query)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=play_url, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_stream(url, props_str=""):
    """ Bereitet den Stream vor und injiziert dynamisch alle DRM/KODIPROP Parameter """
    if USE_PROXY_FOR_ERT and "ert" in url.lower():
        url += f"|http_proxy={urllib.parse.quote_plus(GREEK_PROXY)}"
    
    if "archive.org" in url.lower():
        if "|" not in url:
            url += f"|User-Agent={urllib.parse.quote_plus(DEFAULT_UA)}"
        else:
            url += f"&User-Agent={urllib.parse.quote_plus(DEFAULT_UA)}"
        
    play_item = xbmcgui.ListItem(path=url)
    
    # Standard-Eigenschaften für adaptive Streams setzen
    if ".m3u8" in url.lower() or ".mpd" in url.lower() or "live" in url.lower():
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        if ".m3u8" in url.lower():
            play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        elif ".mpd" in url.lower():
            play_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        play_item.setProperty('inputstream.adaptive.stream_headers', f'User-Agent={urllib.parse.quote_plus(DEFAULT_UA)}')

    # Injektion der aus der M3U ausgelesenen KODIPROP-Werte
    if props_str:
        props = urllib.parse.parse_qs(props_str)
        for key, val_list in props.items():
            if not val_list:
                continue
            val = val_list[0]  # Ersten Wert aus der parse_qs-Liste extrahieren
            play_item.setProperty(key, val)
            
            # GRIECHISCH/CLEARKEY-FIX FÜR ERT1 & ERT2:
            # Falls "inputstream.adaptive.drm" geladen wird, setzen wir auch den direkten Lizenzschlüssel,
            # da neuere Versionen von inputstream.adaptive ClearKey dort erwarten.
            if key == "inputstream.adaptive.drm" and "clearkey" in val.lower():
                play_item.setProperty("inputstream.adaptive.drm_legacy", val)
                # Extrahiert den reinen Key-String (alles nach dem |) für 'inputstream.adaptive.license_key'
                if "|" in val:
                    clean_key = val.split("|")[1]
                    play_item.setProperty("inputstream.adaptive.license_key", clean_key)

    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)

def main():
    """ Hauptsteuerung des Addons basierend auf den URL-Parametern """
    query_string = sys.argv[2] if len(sys.argv) > 2 else ""
    args = urllib.parse.parse_qs(query_string.lstrip('?'))
    
    action = args.get('action', [None])[0]
    
    if action is None:
        show_categories()
    elif action == 'list_channels':
        category = args.get('category', [None])[0]
        show_channels(category)
    elif action == 'play':
        stream_url = args.get('url', [None])[0]
        props_str = args.get('props', [""])[0]
        play_stream(stream_url, props_str)

if __name__ == '__main__':
    main()
