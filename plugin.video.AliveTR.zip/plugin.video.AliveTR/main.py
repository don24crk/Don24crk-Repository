import sys
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Addon Konstanten
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Kategorien und dazugehörige M3U-Playlists
CATEGORIES = {
    "LiveTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/TurkTV.m3u",
    "KemalSunalFilmIzle": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/KemalSunal.m3u",
    "BollywoodFilmIzle": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/Bollywoodfilmizle.m3u",
    "CocukFilmIzle": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/Cocukfilmizle.m3u",
}

def get_m3u_content(url):
    """Lädt den Inhalt der M3U-Playlist herunter."""
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        xbmc.log(f"[AliveTR] Fehler beim Laden der M3U: {str(e)}", xbmc.LOGERROR)
        return ""

def parse_m3u(content):
    """Parst M3U-Einträge inklusive Logos, Fanarts und YouTube Links."""
    playlist = []
    # Regex sucht nach #EXTINF und fängt optionale Attribute sowie den Stream-Link ab
    pattern = re.compile(r'#EXTINF:.*?(?:tvg-logo="([^"]*)")?.*?(?:fanart-image="([^"]*)")?,(.*)\n(https?://[^\s]+)', re.IGNORECASE)
    
    matches = pattern.findall(content)
    for match in matches:
        logo = match[0] if match[0] else ""
        fanart = match[1] if match[1] else ""
        title = match[2].strip()
        stream_url = match[3].strip()
        
        playlist.append({
            "title": title,
            "url": stream_url,
            "logo": logo,
            "fanart": fanart
        })
    return playlist

def show_categories():
    """Zeigt das Hauptmenü mit den Kategorien an."""
    for category in CATEGORIES.keys():
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({'icon': 'DefaultFolder.png', 'thumb': 'DefaultFolder.png'})
        
        # URL-Parameter für den Klick auf eine Kategorie erstellen
        url = f"{BASE_URL}?action=show_channels&category={urllib.parse.quote_plus(category)}"
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=True)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def show_channels(category_name):
    """Zeigt die Kanäle/Filme innerhalb einer gewählten Kategorie an."""
    m3u_url = CATEGORIES.get(category_name)
    if not m3u_url:
        return

    m3u_content = get_m3u_content(m3u_url)
    channels = parse_m3u(m3u_content)

    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel["title"])
        
        # Setze Poster/Thumbnails und Hintergrundbilder aus der M3U
        art = {}
        if channel["logo"]:
            art['thumb'] = channel["logo"]
            art['icon'] = channel["logo"]
        if channel["fanart"]:
            art['fanart'] = channel["fanart"]
        list_item.setArt(art)
        
        list_item.setInfo('video', {'title': channel["title"]})
        list_item.setProperty('IsPlayable', 'true')

        url = f"{BASE_URL}?action=play&video_url={urllib.parse.quote_plus(channel['url'])}"
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(video_url):
    """Spielt das gewählte Video ab und konfiguriert Erweiterungen."""
    list_item = xbmcgui.ListItem(path=video_url)
    
    # 1. YouTube-Links direkt über das offizielle YouTube-Plugin abspielen
    if "youtube.com" in video_url or "youtu.be" in video_url:
        video_id = ""
        if "youtu.be/" in video_url:
            video_id = video_url.split("youtu.be/")[1].split("?")[0]
        elif "v=" in video_url:
            video_id = video_url.split("v=")[1].split("&")[0]
            
        if video_id:
            youtube_plugin_url = f"plugin://plugin.video.youtube/play/?video_id={video_id}"
            list_item.setPath(youtube_plugin_url)

    # 2. HLS / m3u8 Streams mit inputstream.adaptive konfigurieren
    elif ".m3u8" in video_url.lower():
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setProperty('inputstream.adaptive.stream_headers', 'User-Agent=Mozilla/5.0')

    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)

def router(paramstring):
    """Routet die Parameter-Anfragen an die passenden Funktionen."""
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')

    if not action:
        show_categories()
    elif action == 'show_channels':
        show_channels(params.get('category'))
    elif action == 'play':
        play_video(params.get('video_url'))

if __name__ == '__main__':
    router(sys.argv[2])
