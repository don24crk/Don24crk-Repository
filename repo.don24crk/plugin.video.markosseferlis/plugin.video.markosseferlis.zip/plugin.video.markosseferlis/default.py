# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: Don24crk
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.markosseferlis'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PLb04dvHextKvDpqTUsPuC-ewTUYgoYoAk" 	#Markos Seferlis Theatro
YOUTUBE_CHANNEL_ID_2 = "PL0YGQVj2XPIusOHuKSo5BS49z4PPzy3xy" 	#Προσοχή Μαρκοπέδιο!  Full Episodia
YOUTUBE_CHANNEL_ID_3 = "PL0YGQVj2XPIuwxS3FzJ8DatLETt3Ftu2M" 	#Κορίτσια Ο Μάρκουλης Full Episodia


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Markos Seferlis Theatro",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.ytimg.com/vi/TshxTDTMLHA/hqdefault.jpg?sqp=-oaymwEjCPYBEIoBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDARcalzwU1933zEPfjVDUDadE5_A",
		fanart="https://yt3.ggpht.com/iyZlNUxMlProCSdju9atIfWw8LXeWZn9yjeT7hF368i2mnaIIrbRLLr3cBG4yF1cn8jBO0SorQ=w2560-fcrop64=1,00005a57ffffa5a8-nd-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Προσοχή Μαρκοπέδιο!  Full Episodia",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://i.ytimg.com/vi/ZhJ6OTqhK_0/hqdefault.jpg?sqp=-oaymwEiCKgBEF5IWvKriqkDFQgBFQAAAAAYASUAAMhCPQCAokN4AQ==&rs=AOn4CLC8ue44JqHapO5WIR7086sOKWSr3w",
		fanart="https://yt3.ggpht.com/iyZlNUxMlProCSdju9atIfWw8LXeWZn9yjeT7hF368i2mnaIIrbRLLr3cBG4yF1cn8jBO0SorQ=w2560-fcrop64=1,00005a57ffffa5a8-nd-c0xffffffff-rj-k-no",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Κορίτσια Ο Μάρκουλης Full Episodia",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.ytimg.com/vi/bTN2f7mvFmY/hqdefault.jpg?sqp=-oaymwEjCPYBEIoBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLDSZ_I3k37i5HCaBo9TBd7f6EASGw",
		fanart="https://yt3.ggpht.com/iyZlNUxMlProCSdju9atIfWw8LXeWZn9yjeT7hF368i2mnaIIrbRLLr3cBG4yF1cn8jBO0SorQ=w2560-fcrop64=1,00005a57ffffa5a8-nd-c0xffffffff-rj-k-no",
        folder=True )

		
run()
