# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: Don24crk
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.Greekflix'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PL4H0usfiR-CgTQOqe85MqbHTqV9w2Z3GB" 	#ΕΛΛΗΝΙΚΕΣ ΤΑΙΝΙΕΣ 1950-1975
YOUTUBE_CHANNEL_ID_2 = "PLb04dvHextKsxbCNEz54-mYm1ZZeROjBU" 	#ΕΛΛΗΝΙΚΕΣ ΤΑΙΝΙΕΣ (Greekflix Kodi Addon)
YOUTUBE_CHANNEL_ID_3 = "PLhMqdLlJ2iAkkAddoN7vRgZvkx-ps0PLl" 	#Παλιές Ελληνικές Ταινίες HD (Ολόκληρες)


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="ΕΛΛΗΝΙΚΕΣ ΤΑΙΝΙΕΣ 1950-1975",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.ytimg.com/vi/LrYlWY23DDI/hqdefault.jpg?sqp=-oaymwEjCPYBEIoBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLC4_sFNVYqd4a2Gg5xGlwZLxGMKAw",
		fanart="https://i.ytimg.com/vi/VK6wYcRwxdM/hqdefault.jpg?sqp=-oaymwEjCPYBEIoBSFryq4qpAxUIARUAAAAAGAElAADIQj0AgKJDeAE=&rs=AOn4CLCrrcHhQoHG1ho6Dy-BmMHcgI1adw",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="ΕΛΛΗΝΙΚΕΣ ΤΑΙΝΙΕΣ (Greekflix Kodi Addon)",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://www.inthenews.gr/wp-content/uploads/2014/06/palies-ellinikes-tainies.jpg",
		fanart="https://3.bp.blogspot.com/-Dh1MV-KTdKY/UhVixBIDEII/AAAAAAAA7KI/oIF5qMBdXTI/s1600/finos-film_on_Youtube_64.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Παλιές Ελληνικές Ταινίες HD (Ολόκληρες)",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://i.ytimg.com/vi/rwdnr9q3zDI/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLD8958uladuz1jmuC47gANRkcWNzw",
		fanart="https://i.ytimg.com/vi/GAsWxDGWUwc/hqdefault.jpg?sqp=-oaymwEXCPYBEIoBSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLBVLtye7BPqVNEr_y3TwToXI2XsCw",
        folder=True )

		
run()
