# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: Don24crk
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.ufoaddon'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "UCo45JTvlebmXEUzOvjkCouQ" 	            #UFO YT Channel
YOUTUBE_CHANNEL_ID_2 = "PLb04dvHextKu6Tv4jStNOZZPY5mVEZVK9" 	#UFO Addon
YOUTUBE_CHANNEL_ID_3 = "UClXZugRqT3FQu7MbqCxJH4w" 	            #Ultimate Doku YT Channel


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="UFO YT Channel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7dgACnSHzRKUa6EIPhf0h0UzkY_2cB8L3S5__MGEmI9IluaEi",
		fanart="https://i.pinimg.com/originals/dd/c1/c5/ddc1c529e7c1d655658273bb823adc6a.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="UFO Addon",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7dgACnSHzRKUa6EIPhf0h0UzkY_2cB8L3S5__MGEmI9IluaEi",
		fanart="https://i.pinimg.com/originals/dd/c1/c5/ddc1c529e7c1d655658273bb823adc6a.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Ultimate Doku YT Channel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7dgACnSHzRKUa6EIPhf0h0UzkY_2cB8L3S5__MGEmI9IluaEi",
		fanart="https://i.pinimg.com/originals/dd/c1/c5/ddc1c529e7c1d655658273bb823adc6a.jpg",
        folder=True )

		
run()
