# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: Don24crk
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.dimotikaekpombes2019'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PLb04dvHextKufEjE0dkl7bNgBzS6fGI9b" 	#Dimotika Ekpombes 2019



# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

   

    plugintools.add_item( 
        #action="", 
        title="Dimotika Ekpombes 2019",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://i.ibb.co/JmNRd8y/icon.png",
		fanart="https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/cd5a5564-a048-4152-8dd7-338c41284960/db3lj5l-1a347f09-5881-46bf-add5-7c63be99ab56.jpg/v1/fill/w_340,h_250,q_70,strp/1821_greek_civil_war__by_orestix_db3lj5l-250t.jpg?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NzU0IiwicGF0aCI6IlwvZlwvY2Q1YTU1NjQtYTA0OC00MTUyLThkZDctMzM4YzQxMjg0OTYwXC9kYjNsajVsLTFhMzQ3ZjA5LTU4ODEtNDZiZi1hZGQ1LTdjNjNiZTk5YWI1Ni5qcGciLCJ3aWR0aCI6Ijw9MTAyNCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.0C7kh-Ga3bcFTV5mxFT_l6LYt1UtZGtcDUorh8TR2M0",
        folder=True )

 
		
run()
