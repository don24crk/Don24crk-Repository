# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: Don24crk
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.michaeljackson'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "michaeljackson" 	                    #Michael Jackson YT Channel
YOUTUBE_CHANNEL_ID_2 = "PLYagrqIg-kgRH58n973HG8lE-98sPxp3T" 	#Michael Jackson Musikvideos
YOUTUBE_CHANNEL_ID_3 = "UUulYu1HEIa7f70L2lYZWHOw" 	            #Michael Jackson Mix


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Michael Jackson YT Channel",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9KelwntUKwRCifG60J3DUQhLbUnMvrJDgbuu5zyvUWOJVoRTm",
		fanart="https://stmed.net/sites/default/files/michael-jackson-wallpapers-30484-9497745.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Michael Jackson Musikvideos",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://www.eironons.com/thumbnail.asp?file=assets/images/michaeljacksonlogomusict-shirtiron-ontransferdecalmmj6-1.jpg&maxx=450&maxy=450",
		fanart="https://stmed.net/sites/default/files/michael-jackson-wallpapers-30484-9497745.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Michael Jackson Mix",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://www.sggaming.com/Uploads/GAMECENTER/Game/GameLogo/Small-MJ-Legend-Logo.png",
		fanart="https://stmed.net/sites/default/files/michael-jackson-wallpapers-30484-9497745.jpg",
        folder=True )

		
run()
