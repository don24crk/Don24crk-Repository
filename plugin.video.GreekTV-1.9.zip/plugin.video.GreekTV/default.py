import sys
import os
import urllib.parse
import re
import time
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

# Addon-Initialisierung
ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

# INTERNET-STREAM-CHECK: Versuche, das inputstream.helper Modul zu importieren
try:
    import inputstreamhelper
except ImportError:
    inputstreamhelper = None

# Robustes Auslesen der Kodi-Argumente ohne eckige Klammern
ARGV_EXTRACT = list(sys.argv)
BASE_URL = ARGV_EXTRACT.pop(0) if len(ARGV_EXTRACT) > 0 else ""
ADDON_HANDLE_STR = ARGV_EXTRACT.pop(0) if len(ARGV_EXTRACT) > 0 else "-1"
ADDON_HANDLE = int(ADDON_HANDLE_STR) if ADDON_HANDLE_STR.replace("-", "").isdigit() else -1

# OFFLINE-KONFIGURATION: Pfade zu den lokalen M3U-Dateien im Ordner 'resources'
PLAYLISTS = {
    "LiveTV": os.path.join(ADDON_PATH, "resources", "gr.m3u"),
    "Supermammi": os.path.join(ADDON_PATH, "resources", "SUPERMAMMI.m3u"),
    "Jesusmovies": os.path.join(ADDON_PATH, "resources", "JESUSMOVIES.m3u"),
    "Kidsmovies": os.path.join(ADDON_PATH, "resources", "KIDSMOVIES.m3u"),
    "Greekmovies": os.path.join(ADDON_PATH, "resources", "GreekMovies.m3u"),
    "Seflix": os.path.join(ADDON_PATH, "resources", "SEFLIX.m3u"),
    "AlikiVougiouklaki Tenies": os.path.join(ADDON_PATH, "resources", "AlikiVougioklakiTenies.m3u"),
}

def build_url(query):
    """ Erstellt eine Kodi-konforme Addon-URL aus einem Dictionary """
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def convert_youtube_url(url):
    """ Extrahiert die Video-ID aus YouTube-Links absolut absturzsicher """
    video_id = None
    
    if "youtube.com" in url or "youtu.be" in url:
        url_clean = url.split(" ").pop(0).strip()
        
        if "watch" in url_clean or "?v=" in url_clean or "&v=" in url_clean:
            parsed_url = urllib.parse.urlparse(url_clean)
            queries = urllib.parse.parse_qs(parsed_url.query)
            v_param = queries.get("v")
            if v_param:
                v_list = list(v_param)
                if len(v_list) > 0:
                    video_id = v_list.pop(0)
        elif "youtu.be/" in url_clean:
            parsed_url = urllib.parse.urlparse(url_clean)
            video_id = parsed_url.path.strip("/")
            if "/" in video_id:
                video_id = video_id.split("/").pop(0)
        
    if video_id:
        return f"plugin://plugin.video.youtube/play/?video_id={video_id}"
        
    return url

def parse_local_m3u(local_path):
    """ Streamt die M3U und extrahiert Name, tvg-logo, fanart-image sowie Streams/YouTube """
    channels = []
    if not os.path.exists(local_path):
        xbmc.log(f"[Addon] M3U-Datei nicht gefunden: {local_path}", xbmc.LOGERROR)
        return channels

    try:
        logo_pattern = re.compile(r'tvg-logo="([^"]*)"', re.IGNORECASE)
        fanart_pattern = re.compile(r'fanart-image="([^"]*)"', re.IGNORECASE)
        
        current_name = ""
        current_logo = ""
        current_fanart = ""

        with open(local_path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                
                if line.startswith("#EXTINF:"):
                    logo_match = logo_pattern.search(line)
                    current_logo = logo_match.group(1).strip() if logo_match else ""
                    
                    fanart_match = fanart_pattern.search(line)
                    current_fanart = fanart_match.group(1).strip() if fanart_match else ""
                    
                    if "," in line:
                        split_list = line.split(",", 1)
                        if len(split_list) > 0:
                            current_name = split_list.pop(-1).strip()
                        else:
                            current_name = "Unbekannter Sender"
                    else:
                        current_name = "Unbekannter Sender"
                        
                elif line.startswith("http") or line.startswith("https") or line.startswith("plugin://") or os.path.exists(line):
                    if current_name:
                        final_url = convert_youtube_url(line)
                        channels.append({
                            "name": current_name,
                            "logo": current_logo,
                            "fanart": current_fanart,
                            "url": final_url
                        })
                        current_name = ""
                        current_logo = ""
                        current_fanart = ""
    except Exception as e:
        xbmc.log(f"[Addon] Fehler beim Parsen der lokalen M3U: {str(e)}", xbmc.LOGERROR)
        
    return channels

# Hauptmenü-Steuerung
def main():
    query_string = ""
    raw_args = list(sys.argv)
    if len(raw_args) > 2:
        query_string = raw_args.pop(2)
        
    if query_string.startswith("?"):
        query_string = query_string.replace("?", "", 1)
        
    params = dict(urllib.parse.parse_qsl(query_string)) if query_string else {}
    mode = params.get("mode")

    if not mode:
        # Hauptmenü: Kategorien anzeigen
        for category in PLAYLISTS.keys():
            url = build_url({"mode": "list_channels", "category": category})
            li = xbmcgui.ListItem(label=category)
            
            # Integration von lokalem Icon und Fanart für das Hauptmenü
            main_art = {}
            main_art["icon"] = os.path.join(ADDON_PATH, "resources", "greektvicon.png")
            main_art["thumb"] = os.path.join(ADDON_PATH, "resources", "greektvicon.png")
            main_art["fanart"] = os.path.join(ADDON_PATH, "resources", "greekflag.jpg")
            li.setArt(main_art)
            
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    elif mode == "list_channels":
        category = params.get("category")
        file_path = PLAYLISTS.get(category)
        
        if category == "LiveTV":
            xbmcplugin.setContent(ADDON_HANDLE, "videos")
        else:
            xbmcplugin.setContent(ADDON_HANDLE, "movies")
        
        if file_path:
            channels = parse_local_m3u(file_path)
            
            for channel in channels:
                url = build_url({"mode": "play", "url": channel.get("url"), "title": channel.get("name")})
                li = xbmcgui.ListItem(label=channel.get("name"))
                
                video_info = li.getVideoInfoTag()
                video_info.setMediaType("movie")
                video_info.setTitle(channel.get("name"))
                
                art_dict = {}
                logo = channel.get("logo")
                fanart = channel.get("fanart")
                
                if logo:
                    art_dict["thumb"] = logo
                    art_dict["icon"] = logo
                if fanart:
                    art_dict["fanart"] = fanart
                    
                if art_dict:
                    li.setArt(art_dict)
                
                li.setProperty("IsPlayable", "true")
                xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
                
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    elif mode == "play":
        stream_url = params.get("url")
        video_title = params.get("title", "Video")
        
        li = xbmcgui.ListItem(path=stream_url)
        video_info = li.getVideoInfoTag()
        video_info.setMediaType("movie")
        video_info.setTitle(video_title)
        
        # INPUTSTREAM: Typ-Erzwingung basierend auf Dateiendung
        is_adaptive = False
        if ".mpd" in stream_url.lower():
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            is_adaptive = True
        elif ".m3u8" in stream_url.lower():
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
            is_adaptive = True

        # BUGFIX INPUTSTREAMHELPER: Korrekte Übergabe der Addon-Instanz
        if is_adaptive and inputstreamhelper and ADDON_HANDLE >= 0:
            try:
                # Reicht den exakten Kontext an das Widevine-System weiter
                helper = inputstreamhelper.Helper('video', drm='widevine')
                if not helper.check_inputstream():
                    xbmc.log("[Addon] Widevine-Installation abgebrochen oder fehlgeschlagen.", xbmc.LOGERROR)
                    return
            except Exception as helper_err:
                # Fail-Safe, falls der Helper im aktuellen Skin blockiert
                xbmc.log(f"[Addon] InputStreamHelper Fehler abgefangen: {str(helper_err)}", xbmc.LOGWARNING)

        # Resume-Logik auslesen
        resume_time = xbmc.getInfoLabel('ListItem.ResumeTime')
        seek_seconds = 0
        if resume_time and str(resume_time).isdigit():
            seek_seconds = int(resume_time)
        
        if seek_seconds > 0:
            li.setProperty('StartOffset', str(seek_seconds))
            
        li.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=li)
        
        # Erzwungener Sprung (Resume-Fallback nach Player-Initialisierung)
        if seek_seconds > 0:
            for _ in range(30):
                if xbmc.Player().isPlaying():
                    time.sleep(0.5)
                    xbmc.Player().seekTime(seek_seconds)
                    break
                time.sleep(0.2)

if __name__ == "__main__":
    main()
