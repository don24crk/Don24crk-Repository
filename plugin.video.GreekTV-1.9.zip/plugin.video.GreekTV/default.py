import sys
import urllib.parse
import urllib.request
import urllib.error
import re
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Versuche, das inputstream.helper Modul zu importieren
try:
    import inputstreamhelper
except ImportError:
    inputstreamhelper = None

# Addon-Initialisierung
ADDON = xbmcaddon.Addon()

# Korrekte Syntax für Kodi sys.argv Indizes
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1

# Kategorien und dazugehörige M3U-Playlists
PLAYLISTS = {
    "LiveTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "Supermammi": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SUPERMAMMI.m3u",
    "Jesusmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/JESUSMOVIES.m3u",
    "Kidsmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/KIDSMOVIES.m3u",
    "Greekmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/GreekMovies.m3u",
    "Seflix": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SEFLIX.m3u",
    "AlikiVougiouklaki Tenies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/AlikiVougioklakiTenies.m3u",
}

DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0"

# GRIECHISCHE PROXY-KONFIGURATION (Bypass für ERT1/ERT2)
GREEK_PROXY = "http://46.12.17.24:8080" 
USE_PROXY_FOR_ERT = True

def build_url(query):
    """ Erstellt eine Kodi-konforme Addon-URL aus einem Dictionary """
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def fetch_m3u(url):
    """ Lädt die M3U-Playlist und erzwingt UTF-8 Dekodierung """
    try:
        req = urllib.request.Request(url, headers={'User-Agent': DEFAULT_UA})
        with urllib.request.urlopen(req, timeout=12) as response:
            return response.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as e:
        xbmc.log(f"[GreekTV] HTTP Fehler {e.code} für URL: {url}", xbmc.LOGERROR)
        if e.code == 404:
            xbmcgui.Dialog().notification("Fehler", "Playlist nicht gefunden (404).", xbmcgui.NOTIFICATION_ERROR, 4000)
        return ""
    except Exception as e:
        xbmc.log(f"[GreekTV] Allgemeiner Fehler beim Laden der URL: {str(e)}", xbmc.LOGERROR)
        return ""

def parse_m3u(data):
    """ Parsed M3U zeilenweise. Absolut stabil, auch wenn Attribute fehlen. """
    channels = []
    lines = data.splitlines()
    
    current_channel = None
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        if line.startswith("#EXTINF:"):
            current_channel = {}
            
            # Name extrahieren (alles nach dem letzten Komma in der EXTINF Zeile)
            title_match = re.search(r',([^\r\n]*)$', line)
            current_channel['name'] = title_match.group(1).strip() if title_match else "Unbekannter Sender"
            
            # Attribute extrahieren mittels separater, sicherer Regex-Suchen
            logo_match = re.search(r'tvg-logo="([^"]*)"', line, re.IGNORECASE)
            fanart_match = re.search(r'fanart-image="([^"]*)"', line, re.IGNORECASE)
            
            current_channel['logo'] = logo_match.group(1).strip() if logo_match else ""
            current_channel['fanart'] = fanart_match.group(1).strip() if fanart_match else ""
            
        elif line.startswith("http://") or line.startswith("https://"):
            if current_channel is not None:
                current_channel['url'] = line
                channels.append(current_channel)
                current_channel = None # Zurücksetzen für den nächsten Sender
                
    return channels

def main():
    """ Hauptsteuerung des Addons """
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        query_str = sys.argv[2].lstrip('?')
        params = dict(urllib.parse.parse_qsl(query_str))
        
    mode = params.get('mode')
    
    # 1. Hauptmenü: Kategorien anzeigen
    if not mode:
        for name in PLAYLISTS.keys():
            url = build_url({'mode': 'show_category', 'category': name})
            list_item = xbmcgui.ListItem(label=name)
            list_item.setArt({'icon': 'https://img.samsungapps.com/productNew/000008070827/ENG/IconImage_20260727041347081_NEW_WAP_ICON_512_512.png', 'fanart': 'https://wallpapers4screen.com/Uploads/19-7-2022/40083/thumb2-4k-greece-flag-stone-texture-flag-of-greece-stone-background.jpg'})
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=True)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        
    # 2. Untermenü: Kanäle einer Kategorie auflisten
    elif mode == 'show_category':
        category = params.get('category')
        playlist_url = PLAYLISTS.get(category)
        
        if playlist_url:
            m3u_data = fetch_m3u(playlist_url)
            channels = parse_m3u(m3u_data)
            
            for channel in channels:
                stream_url = channel['url']
                
                # SONDERLOGIK 1: archive.org Links benötigen korrekte Header für Kodi
                if "archive.org" in stream_url.lower():
                    # Archive.org mag es, wenn der Referer auf die Basis-Domain zeigt
                    stream_url += f"|User-Agent={urllib.parse.quote_plus('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0')}&Referer={urllib.parse.quote('https://archive.org')}"
                
                # SONDERLOGIK 2: Proxy-Logik für ERT-Sender anwenden falls aktiviert
                elif USE_PROXY_FOR_ERT and "ert" in channel['name'].lower():
                    stream_url += f"|proxy={urllib.parse.quote(GREEK_PROXY)}&User-Agent={urllib.parse.quote(DEFAULT_UA)}"
                
                # Standardfall: Wenn weder archive.org noch ERT-Proxy zutreffen
                else:
                    stream_url += f"|User-Agent={urllib.parse.quote('Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0')}&Referer={urllib.parse.quote('https://archive.org')}"
                
                url = build_url({'mode': 'play_stream', 'url': stream_url})
                list_item = xbmcgui.ListItem(label=channel['name'])
                
                # Modernes InfoTag für Kodi 20/21+ nutzen, Fallback für ältere Versionen
                try:
                    video_info = list_item.getVideoInfoTag()
                    video_info.setTitle(channel['name'])
                except AttributeError:
                    list_item.setInfo('video', {'title': channel['name']})
                
                list_item.setProperty('IsPlayable', 'true')
                
                # Grafiken (tvg-logo und fanart-image) einbinden
                graphics = {}
                if channel['logo']:
                    graphics['thumb'] = channel['logo']
                    graphics['icon'] = channel['logo']
                if channel['fanart']:
                    graphics['fanart'] = channel['fanart']
                
                if graphics:
                    list_item.setArt(graphics)
                
                xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=False)
                
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

    # 3. Stream abspielen
    elif mode == 'play_stream':
        stream_url = params.get('url')
        play_item = xbmcgui.ListItem(path=stream_url)
        
        # Falls es sich um ein adaptives Video (DASH/HLS) von Archive handelt, InputStream nutzen
        if ".m3u8" in stream_url.lower() or ".mpd" in stream_url.lower():
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            
            if ".m3u8" in stream_url.lower():
                play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            elif ".mpd" in stream_url.lower():
                play_item.setProperty('inputstream.adaptive.manifest_type', 'dash')
                
            if inputstreamhelper:
                helper = inputstreamhelper.Helper('mpd' if '.mpd' in stream_url.lower() else 'hls')
                if not helper.check_inputstream():
                    xbmc.log("[GreekTV] InputStream.Adaptive Prüfung fehlgeschlagen.", xbmc.LOGWARNING)
        
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, play_item)

if __name__ == '__main__':
    main()

