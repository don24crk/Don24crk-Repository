import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
import urllib.parse

addon = xbmcaddon.Addon(id='plugin.video.don24crks_indialivetv')
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'

M3U_URL = 'https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/in.m3u'

def get_m3u_channels(url):
    import requests
    headers = {'User-Agent': USER_AGENT}
    response = requests.get(url, headers=headers, timeout=10)
    response.raise_for_status()
    lines = response.text.splitlines()
    channels = []
    for i in range(len(lines)):
        if lines[i].startswith('#EXTINF:'):
            info = lines[i]
            if i + 1 < len(lines):
                stream_url = lines[i + 1].strip()
                # Extract channel name from EXTINF line
                name_start = info.find(',') + 1
                name = info[name_start:].strip()
                channels.append({'name': name, 'url': stream_url})
    return channels

def list_channels():
    try:
        channels = get_m3u_channels(M3U_URL)
    except Exception as e:
        xbmcgui.Dialog().notification('Error', 'Failed to load channels', xbmcgui.NOTIFICATION_ERROR)
        return
    for ch in channels:
        li = xbmcgui.ListItem(label=ch['name'])
        li.setProperty('IsPlayable', 'true')
        url = build_url({'mode': 'play', 'stream_url': ch['url']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def play_stream(stream_url):
    li = xbmcgui.ListItem(path=stream_url)
    li.setProperty('inputstreamaddon', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    li.setProperty('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36')
    xbmcplugin.setResolvedUrl(addon_handle, True, li)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')
    if mode == 'play':
        stream_url = params.get('stream_url')
        if stream_url:
            play_stream(stream_url)
    else:
        list_channels()

if __name__ == '__main__':
    router(sys.argv[2][1:])