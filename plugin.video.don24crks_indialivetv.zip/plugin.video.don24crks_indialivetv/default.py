import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import sys
from urllib.parse import parse_qs

addon = xbmcaddon.Addon(id='plugin.video.don24crks_indialivetv')
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

# Sample M3U playlist URL for India Live TV channels
M3U_URL = "https://raw.githubusercontent.com/iptv-org/iptv/refs/heads/master/streams/in.m3u"

def get_m3u_channels(m3u_url):
    import requests
    channels = []
    try:
        response = requests.get(m3u_url, timeout=10)
        response.raise_for_status()
        lines = response.text.splitlines()
        for i, line in enumerate(lines):
            if line.startswith("#EXTINF:"):
                info = line
                url = lines[i+1] if i+1 < len(lines) else None
                if url and url.startswith("http"):
                    # Extract channel name from EXTINF line
                    name_start = info.find(",") + 1
                    name = info[name_start:].strip()
                    channels.append({"name": name, "url": url})
    except Exception as e:
        xbmcgui.Dialog().notification("IndiaLiveTV", f"Failed to load playlist: {e}", xbmcgui.NOTIFICATION_ERROR)
    return channels

def list_channels():
    channels = get_m3u_channels(M3U_URL)
    for idx, channel in enumerate(channels):
        li = xbmcgui.ListItem(label=channel["name"])
        li.setInfo("video", {"title": channel["name"]})
        li.setProperty("IsPlayable", "true")
        url = f"{base_url}?action=play&url={channel['url']}"
        xbmcplugin.addDirectoryItem(addon_handle, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def play_channel(url):
    play_item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def router(paramstring):
    params = parse_qs(paramstring)
    action = params.get("action", [None])[0]
    if action == "play":
        url = params.get("url", [None])[0]
        if url:
            play_channel(url)
    else:
        list_channels()

if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")