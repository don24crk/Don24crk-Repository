import sys
import urllib.parse
import urllib.request
import re
import xbmc
import xbmcgui
import xbmcplugin

# Basis-Variablen für das Kodi-Routing
PLUGIN_URL = sys.argv[0]
HANDLE = int(sys.argv[1])

# M3U Playlist-URLs für jedes Land (Ersetze diese Platzhalter mit deinen echten M3U-Links)
M3U_PLAYLISTS = {
    "greektv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "italiantv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/it.m3u",
    "francetv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/fr.m3u",
    "polskytv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/pl.m3u",
    "spanischtv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/es.m3u",
    "turktv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/TurkTV.m3u",
    "germantv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/ger.m3u",
    "usatv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/us.m3u",
    "indiatv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/in.m3u",
}

def get_params():
    """Analysiert die Parameter, die Kodi an das Skript übergibt."""
    param_string = sys.argv[2] if len(sys.argv) > 2 else ''
    if param_string:
        return dict(urllib.parse.parse_qsl(param_string.lstrip('?')))
    return {}

def build_url(query):
    """Erstellt eine interne Routing-URL für dieses Addon."""
    return f"{PLUGIN_URL}?{urllib.parse.urlencode(query)}"

def show_categories():
    """Erzeugt das Hauptmenü mit der Länderauswahl."""
    for category in M3U_PLAYLISTS.keys():
        list_item = xbmcgui.ListItem(label=category)
        url = build_url({'action': 'list_channels', 'category': category})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def parse_m3u(url):
    """Lädt die M3U-Datei und extrahiert Sendernamen sowie die Stream- oder Plugin-URLs."""
    channels = []
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            content = response.read().decode('utf-8')
        
        # Regex erfasst den Namen nach dem Komma und liest die darauffolgende Zeile (URL) aus
        pattern = re.compile(r'#EXTINF:.*?,(.*?)\n([^\n]+)', re.IGNORECASE)
        matches = pattern.findall(content)
        
        for name, stream_url in matches:
            channels.append({
                'name': name.strip(),
                'url': stream_url.strip()
            })
    except Exception as e:
        xbmc.log(f"Barney.Stinson M3U-Parsing-Fehler: {str(e)}", xbmc.LOGERROR)
    return channels

def list_channels(category):
    """Listet die Sender auf und unterscheidet zwischen YouTube-Plugin-Links und IPTV-Streams."""
    playlist_url = M3U_PLAYLISTS.get(category)
    if not playlist_url:
        return
        
    channels = parse_m3u(playlist_url)
    
    for channel in channels:
        list_item = xbmcgui.ListItem(label=channel['name'])
        list_item.setInfo('video', {'title': channel['name']})
        list_item.setProperty('IsPlayable', 'true')
        
        url_lower = channel['url'].lower()
        
        if 'plugin://plugin.video.youtube' in url_lower:
            # Reicht den YouTube-Plugin-Link direkt an Kodi weiter (kein Umweg über dieses Addon beim Abspielen)
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=channel['url'], listitem=list_item, isFolder=False)
        else:
            # Klassische IPTV-Streams werden über die eigene Play-Funktion geroutet
            playback_url = build_url({'action': 'play', 'url': channel['url']})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=playback_url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_stream(stream_url):
    """Konfiguriert den Player für Standard-IPTV-Streams mittels InputStream Adaptive."""
    list_item = xbmcgui.ListItem(path=stream_url)
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    
    # Format-Zuweisung basierend auf der Dateiendung des Streams
    if '.m3u8' in stream_url.lower():
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    elif '.mpd' in stream_url.lower():
        list_item.setProperty('inputstream.adaptive.manifest_type', 'dash')
    elif '.ism' in stream_url.lower():
        list_item.setProperty('inputstream.adaptive.manifest_type', 'ism')
        
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem=list_item)

def router():
    """Steuert die Menüführung im Addon."""
    params = get_params()
    action = params.get('action')
    
    if not action:
        show_categories()
    elif action == 'list_channels':
        list_channels(params.get('category'))
    elif action == 'play':
        play_stream(params.get('url'))

if __name__ == '__main__':
    router()







