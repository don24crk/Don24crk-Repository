import sys
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

# Addon-Initialisierung
ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

# Kategorien und dazugehörige M3U-Playlists
PLAYLISTS = {
    "LiveTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "Supermammi": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SUPERMAMMI.m3u",
    "Jesusmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/JESUSMOVIES.m3u",
    "Kidsmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/KIDSMOVIES.m3u",
    "Greekmovies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/GreekMovies.m3u",
    "Seflix": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/SEFLIX.m3u",
    "AlikiVougiouklaki Tenies": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/AlikiVougioklakiTenies.m3u",
}

DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"

# GRIECHISCHE PROXY-KONFIGURATION (Bypass für ERT1/ERT2)
GREEK_PROXY = "http://46.12.17.24:8080" 
USE_PROXY_FOR_ERT = True  

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def fetch_m3u(url):
    """ Lädt die M3U-Playlist und fängt 404/HTTP-Fehler sauber ab """
    try:
        req = urllib.request.Request(url, headers={'User-Agent': DEFAULT_UA})
        with urllib.request.urlopen(req, timeout=12) as response:
            return response.read().decode('utf-8', errors='replace')
    except urllib.error.HTTPError as e:
        xbmc.log(f"[GreekTV] HTTP Fehler {e.code} für URL: {url}", xbmc.LOGERROR)
        if e.code == 404:
            xbmcgui.Dialog().notification("GreekTV", "Playlist nicht gefunden (404)", xbmcgui.NOTIFICATION_ERROR, 4000)
    except Exception as e:
        xbmc.log(f"[GreekTV] Verbindungsfehler: {str(e)}", xbmc.LOGERROR)
    return ""

def parse_m3u(data):
    """ Hochgradig robuster M3U-Parser für tvg-logo, fanart-image, STRM und Streaming-Plattformen """
    items = []
    if not data:
        return items

    ua_match = re.search(r'#EXTVLCOPT:http-user-agent=(.*)', data, re.IGNORECASE)
    playlist_ua = ua_match.group(1).strip() if ua_match else DEFAULT_UA

    lines = data.splitlines()
    current_inf = None

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if line.startswith('#EXTINF:'):
            current_inf = line
            continue
        
        if line.startswith('#'):
            continue

        if current_inf:
            url = line
            
            logo_match = re.search(r'tvg-logo\s*=\s*["\']([^"\']*)["\']', current_inf, re.IGNORECASE)
            logo = logo_match.group(1).strip() if logo_match else ""

            fanart_match = re.search(r'fanart-image\s*=\s*["\']([^"\']*)["\']', current_inf, re.IGNORECASE)
            fanart = fanart_match.group(1).strip() if fanart_match else ""

            name = "Unbekannter Stream"
            if ',' in current_inf:
                name = current_inf.rsplit(',', 1)[1].strip()

            if url.lower().endswith('.strm'):
                try:
                    with open(url, 'r', encoding='utf-8') as f:
                        url = f.read().strip()
                except Exception:
                    xbmc.log(f"[GreekTV] Konnte STRM-Datei nicht lesen: {url}", xbmc.LOGWARNING)
                    current_inf = None
                    continue

            # YouTube Extraktion via Regex (behebt Query-String-Abschneidefehler)
            if "youtube.com" in url or "youtu.be" in url:
                yt_match = re.search(r'(?:v=|/v/|embed/|youtu.be/|shorts/)([^?&"\' >]+)', url)
                if yt_match:
                    url = f"plugin://plugin.video.youtube/play/?video_id={yt_match.group(1)}"

            # Dailymotion Extraktion via Regex
            elif "dailymotion.com" in url or "dai.ly" in url:
                dm_match = re.search(r'(?:video/|dai.ly/)([^?&"\' >]+)', url)
                if dm_match:
                    url = f"plugin://plugin.video.dailymotion_com/?url={dm_match.group(1)}&mode=playVideo"

            # Archive.org Anpassung
            elif "archive.org" in url:
                if not url.lower().endswith('.mp4') and "/details/" in url:
                    url = url.replace("/details/", "/download/")
                    if not url.lower().endswith('.mp4'):
                        url += ".mp4"

            items.append({
                "name": name,
                "url": url,
                "logo": logo,
                "fanart": fanart,
                "ua": playlist_ua
            })
            current_inf = None

    return items

def show_categories():
    """ Zeigt das Hauptmenü mit den definierten Kategorien """
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    for cat_name in PLAYLISTS.keys():
        url = build_url({'action': 'show_category', 'category': cat_name})
        list_item = xbmcgui.ListItem(label=cat_name, offscreen=True)
        list_item.setInfo('video', {'title': cat_name, 'plot': f"Κατηγορία: {cat_name}", 'mediatype': 'video'})
        list_item.setArt({'icon': 'https://img.samsungapps.com/productNew/000008070827/ENG/IconImage_20260727041347081_NEW_WAP_ICON_512_512.png', 'fanart': 'https://wallpapers4screen.com/Uploads/19-7-2022/40083/thumb2-4k-greece-flag-stone-texture-flag-of-greece-stone-background.jpg'})
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def show_category_content(category_name):
    """ Listet die Einträge einer Kategorie auf """
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    playlist_url = PLAYLISTS.get(category_name)
    
    if not playlist_url:
        return

    m3u_data = fetch_m3u(playlist_url)
    items = parse_m3u(m3u_data)

    for item in items:
        list_item = xbmcgui.ListItem(label=item['name'], offscreen=True)
        
        art = {}
        if item['logo']: 
            art['thumb'] = item['logo']
            art['icon'] = item['logo']
        if item['fanart']: 
            art['fanart'] = item['fanart']
        if art: 
            list_item.setArt(art)

        list_item.setInfo('video', {
            'title': item['name'],
            'mediatype': 'video',
            'playcount': 0
        })
        
        list_item.setProperty('IsPlayable', 'true')

        url = build_url({
            'action': 'play', 
            'url': item['url'], 
            'name': item['name'], 
            'ua': item['ua']
        })
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_stream(stream_url, name, ua):
    """ Abspiel-Router für native Streams, DRM (ERT 1/2) mit Proxy-Unterstützung """
    list_item = xbmcgui.ListItem(name, path=stream_url, offscreen=True)
    list_item.setInfo('video', {'title': name, 'mediatype': 'video'})
    
    
    clean_name = name.lower()
    is_ert = any(x in clean_name for x in ["ert1", "ert 1", "ert2", "ert 2"])
    header = f"|User-Agent={urllib.parse.quote(ua)}"
    
    if is_ert and USE_PROXY_FOR_ERT and GREEK_PROXY:
        parsed_proxy = urllib.parse.urlparse(GREEK_PROXY)
        proxy_string = f"&http_proxy={urllib.parse.quote(parsed_proxy.netloc)}"
        header += proxy_string

    if ".mpd" in stream_url or ".m3u8" in stream_url:
        try:
            import inputstreamhelper
            is_helper = inputstreamhelper.Helper('mpd' if ".mpd" in stream_url else 'hls')
            if is_helper.check_inputstream():
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                if ".mpd" in stream_url:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                else:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                
                if is_ert:
                    list_item.setProperty('inputstream.adaptive.license_type', 'org.w3.clearkey')
                    if USE_PROXY_FOR_ERT and GREEK_PROXY:
                        list_item.setProperty('inputstream.adaptive.proxy', GREEK_PROXY)
                        
        except ImportError:
            xbmc.log("[GreekTV] inputstreamhelper Modul fehlt!", xbmc.LOGWARNING)

    if not stream_url.startswith("plugin://"):
        list_item.setPath(f"{stream_url}{header}")
    else:
        list_item.setPath(stream_url)

    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)

def router(paramstring):
    """ Steuerung der Addon-Navigation """
    params = dict(urllib.parse.parse_qsl(paramstring.lstrip('?')))
    action = params.get('action')

    if not action:
        show_categories()
    elif action == 'show_category':
        show_category_content(params.get('category'))
    elif action == 'play':
        play_stream(params.get('url'), params.get('name'), params.get('ua'))

if __name__ == '__main__':
    # Auswertung der Parameter-Kette mit Fallback-Sicherung
    raw_params = sys.argv[2] if len(sys.argv) > 2 else ""
    router(raw_params)
