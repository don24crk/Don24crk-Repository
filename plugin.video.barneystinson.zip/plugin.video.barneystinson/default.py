import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib.parse

addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addon_name = "Barney Stinson"
base_url = sys.argv[0]

LIVE_TV_CHANNELS = {
    "GreekTV":  "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "GermanTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/ger.m3u",
    "TurkTV":   "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/tr.m3u",
    "SpainTV":  "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/es.m3u",
    "FranceTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/fr.m3u",
    "PolskyTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/pl.m3u",
    "ItalianTV":"https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/it.m3u",
    "UsaTV":    "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/us.m3u",
}

STREAM_SOURCES = {
    "Dailymotion": "dailymotion",
    "YouTube": "youtube",
    "Archive.org": "archive",
}

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def list_live_tv():
    for name, url in LIVE_TV_CHANNELS.items():
        li = xbmcgui.ListItem(label=name)
        li.setInfo('video', {'title': name, 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def list_stream_sources():
    for name in STREAM_SOURCES.keys():
        li = xbmcgui.ListItem(label=name)
        url = build_url({'mode': 'stream_url', 'source': name})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def play_stream_url(source):
    keyboard = xbmc.Keyboard('', 'Enter URL to play')
    keyboard.doModal()
    if keyboard.isConfirmed():
        url = keyboard.getText()
        if not url:
            xbmcgui.Dialog().notification(addon_name, "No URL entered", xbmcgui.NOTIFICATION_ERROR)
            return
        # Validate URL based on source
        if source == "Dailymotion":
            if "dailymotion.com" not in url:
                xbmcgui.Dialog().notification(addon_name, "Invalid Dailymotion URL", xbmcgui.NOTIFICATION_ERROR)
                return
        elif source == "YouTube":
            if "youtube.com" not in url and "youtu.be" not in url:
                xbmcgui.Dialog().notification(addon_name, "Invalid YouTube URL", xbmcgui.NOTIFICATION_ERROR)
                return
        elif source == "Archive.org":
            if "archive.org" not in url:
                xbmcgui.Dialog().notification(addon_name, "Invalid Archive.org URL", xbmcgui.NOTIFICATION_ERROR)
                return
        play_item = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem=play_item)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')
    if mode is None:
        # Main menu
        li1 = xbmcgui.ListItem(label="Live TV Channels")
        url1 = build_url({'mode': 'live_tv'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url1, listitem=li1, isFolder=True)

        li2 = xbmcgui.ListItem(label="Stream URL Player")
        url2 = build_url({'mode': 'stream_sources'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url2, listitem=li2, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle)
    elif mode == 'live_tv':
        list_live_tv()
    elif mode == 'stream_sources':
        list_stream_sources()
    elif mode == 'stream_url':
        source = params.get('source')
        if source:
            play_stream_url(source)
        else:
            xbmcgui.Dialog().notification(addon_name, "No source specified", xbmcgui.NOTIFICATION_ERROR)

if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
