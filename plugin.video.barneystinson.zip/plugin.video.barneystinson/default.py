import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = sys.argv[0]

LIVE_TV_CHANNELS = {
    'GreekTV': 'https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/android.m3u',
    'GermanTV': 'https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/GermanTV%20By%20don24crk.m3u',
    'TurkTV': 'https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/TurkTV.m3u',
}

def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)

def list_live_tv():
    for name, url in LIVE_TV_CHANNELS.items():
        li = xbmcgui.ListItem(label=name)
        li.setInfo('video', {'title': name, 'mediatype': 'video'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def play_stream_url(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(addon_handle, True, li)

def list_root():
    li = xbmcgui.ListItem(label='Live TV Channels')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'livetv'}), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label='Play Stream URL')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=build_url({'mode': 'streamurl'}), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def stream_url_input():
    keyboard = xbmc.Keyboard('', 'Enter Stream URL (Dailymotion, YouTube, Archive.org)')
    keyboard.doModal()
    if keyboard.isConfirmed():
        url = keyboard.getText()
        if url:
            play_stream_url(url)
        else:
            xbmcgui.Dialog().notification('Barney Stinson', 'No URL entered', xbmcgui.NOTIFICATION_ERROR)
    else:
        xbmcplugin.endOfDirectory(addon_handle)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')

    if mode is None:
        list_root()
    elif mode == 'livetv':
        list_live_tv()
    elif mode == 'streamurl':
        stream_url_input()
    else:
        xbmcgui.Dialog().notification('Barney Stinson', 'Invalid mode', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(addon_handle)

if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')