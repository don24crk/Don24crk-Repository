import sys
import xbmc
import xbmcplugin
import xbmcgui
import urllib.parse
import requests

# Constants
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

# User-Agent for streaming
USER_AGENT = "Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.187 Mobile Safari/537.36 EdgA/150.0.4078.96"

# Sample M3U playlist URLs (replace with your actual playlist URLs)
PLAYLIST_URLS = {
    'greektv': 'https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u',
    'italiantv': 'https://raw.githubusercontent.com/free-iptv/iptv/master/iptv/playlists/countries/it.m3u',
    'francetv': 'https://raw.githubusercontent.com/free-iptv/iptv/master/iptv/playlists/countries/fr.m3u',
    'polskytv': 'https://raw.githubusercontent.com/free-iptv/iptv/master/iptv/playlists/countries/pl.m3u',
    'spanischtv': 'https://raw.githubusercontent.com/free-iptv/iptv/master/iptv/playlists/countries/es.m3u',
    'turktv': 'https://raw.githubusercontent.com/free-iptv/iptv/master/iptv/playlists/countries/tr.m3u',
    'germantv': 'https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/ger.m3u',
    'usatv': 'https://raw.githubusercontent.com/free-iptv/iptv/master/iptv/playlists/countries/us.m3u',
    'indiatv': 'https://raw.githubusercontent.com/free-iptv/iptv/master/iptv/playlists/countries/in.m3u'
}

# Function to fetch and parse M3U playlist
def fetch_playlist(url):
    headers = {'User-Agent': USER_AGENT}
    response = requests.get(url, headers=headers)
    if response.status_code != 200:
        xbmcgui.Dialog().ok("Error", f"Failed to fetch playlist: {url}")
        return []
    lines = response.text.splitlines()
    items = []
    name = 'Unknown'
    for line in lines:
        line = line.strip()
        if line.startswith('#EXTINF'):
            # Extract channel name
            parts = line.split(',', 1)
            name = parts[1] if len(parts) > 1 else 'Unknown'
        elif line and not line.startswith('#'):
            # Stream URL
            items.append({'name': name, 'url': line})
    return items

# Function to determine manifest type based on URL extension
def get_manifest_type(url):
    url_lower = url.lower()
    if url_lower.endswith('.mpd'):
        return 'mpd'
    elif url_lower.endswith('.m3u8'):
        return 'hls'
    else:
        # Default to mpd or hls based on content (optional)
        return 'mpd'  # fallback

# Function to add items to Kodi with inputstream.adaptive support
def add_directory_item(name, url, is_folder=False):
    list_item = xbmcgui.ListItem(label=name)
    if not is_folder:
        list_item.setInfo('video', {'title': name})
        list_item.setProperty('IsPlayable', 'true')
        # Enable inputstream.adaptive
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        # Determine manifest type
        manifest_type = get_manifest_type(url)
        list_item.setProperty('inputstream.adaptive.manifest_type', manifest_type)
        # Optional: set license_type and license_key if DRM is used
        # list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        # list_item.setProperty('inputstream.adaptive.license_key', 'LICENSE_URL')
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)

# Main menu
def main():
    # Add IPTV channel categories
    for channel in PLAYLIST_URLS:
        add_directory_item(channel.upper(), f'{BASE_URL}?action=playlist&channel={channel}', True)
    # Add platform links
    add_directory_item('YouTube', f'{BASE_URL}?action=platform&platform=youtube', True)
    add_directory_item('Dailymotion', f'{BASE_URL}?action=platform&platform=dailymotion', True)
    add_directory_item('Archive.org', f'{BASE_URL}?action=platform&platform=archive', True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# Handle playlist loading
def handle_playlist(channel):
    url = PLAYLIST_URLS.get(channel)
    if not url:
        xbmcgui.Dialog().ok("Error", f"No playlist URL for {channel}")
        return
    items = fetch_playlist(url)
    for item in items:
        stream_url = item['url']
        add_directory_item(item['name'], stream_url, False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# Handle platform links
def handle_platform(platform):
    if platform == 'youtube':
         add_directory_item('Rick Astley - Never Gonna Give You Up (Official Video)', 'plugin://plugin.video.youtube/play/?video_id=dQw4w9WgXcQ', False)
    elif platform == 'dailymotion':
        add_directory_item('Big Buck Bunny (HD) - Ein animierter Kurzfilm in HD', 'plugin://plugin.video.dailymotion_com/?url=x3d8zey&mode=playVideo', False)
    elif platform == 'archive':
        add_directory_item('Sample Archive.org Item', 'https://archive.org/details/sample', False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# Main execution
if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    if action == 'playlist':
        channel = params.get('channel')
        handle_playlist(channel)
    elif action == 'platform':
        platform = params.get('platform')
        handle_platform(platform)
    else:
        main()
