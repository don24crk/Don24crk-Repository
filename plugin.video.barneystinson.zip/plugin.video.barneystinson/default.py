import os
import sys
import urllib.parse
import urllib.request
import json
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_URL = sys.argv[0]
ADDON_HANDLE = int(sys.argv[1])
USER_AGENT = "Mozilla/5.0 (Linux; Android 10; Pixel 3 XL) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.187 Mobile Safari/537.36 EdgA/150.0.4078.96"

CATEGORIES = {
    "greektv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/gr.m3u",
    "italiantv": "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/it.m3u",
    "francetv": "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/fr.m3u",
    "polskytv": "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/pl.m3u",
    "spanischtv": "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/es.m3u",
    "turktv": "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/tr.m3u",
    "germantv": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/barney%20stinson%20LiveTV/ger.m3u",
    "usatv": "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/us.m3u",
    "indiatv": "https://raw.githubusercontent.com/iptv-org/iptv/master/streams/in.m3u"
}

def get_url(**kwargs):
    return f"{ADDON_URL}?{urllib.parse.urlencode(kwargs)}"

def list_categories():
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    for cat_name in CATEGORIES.keys():
        list_item = xbmcgui.ListItem(label=cat_name.upper())
        list_item.setArt({'icon': 'DefaultVideo.png', 'thumb': 'DefaultVideo.png'})
        url = get_url(action='list_channels', category=cat_name)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def fetch_m3u(url):
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    try:
        with urllib.request.urlopen(req) as response:
            return response.read().decode('utf-8', errors='ignore')
    except Exception:
        return ""

def parse_m3u(data):
    channels = []
    current_title = ""
    for line in data.splitlines():
        line = line.strip()
        if line.startswith("#EXTINF:"):
            if "," in line:
                current_title = line.split(",")[-1]
        elif line and not line.startswith("#"):
            if current_title:
                channels.append((current_title, line))
                current_title = ""
    return channels

def list_channels(category):
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    url = CATEGORIES.get(category)
    if not url:
        return
    
    m3u_data = fetch_m3u(url)
    channels = parse_m3u(m3u_data)

    for title, stream_url in channels:
        list_item = xbmcgui.ListItem(label=title)
        list_item.setInfo('video', {'title': title, 'mediatype': 'video'})
        list_item.setProperty('IsPlayable', 'true')
        
        play_url = get_url(action='play', url=stream_url)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=play_url, listitem=list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_video(url):
    play_url = url
    
    if "youtube.com" in url or "youtu.be" in url:
        if "watch?v=" in url:
            video_id = url.split("watch?v=")[-1].split("&")[0]
        elif "youtu.be/" in url:
            video_id = url.split("youtu.be/")[-1].split("?")[0]
        else:
            video_id = ""
        if video_id:
            play_url = f"plugin://plugin.video.youtube/play/?video_id={video_id}"
            
    elif "dailymotion.com" in url or "dai.ly" in url:
        if "video/" in url:
            video_id = url.split("video/")[-1].split("?")[0]
        elif "dai.ly/" in url:
            video_id = url.split("dai.ly/")[-1].split("?")[0]
        else:
            video_id = ""
        if video_id:
            play_url = f"plugin://plugin.video.dailymotion_loader/play/x{video_id}"

    list_item = xbmcgui.ListItem(path=play_url)
    list_item.setProperty('的风-User-Agent', USER_AGENT)
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, list_item)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    if not action:
        list_categories()
    elif action == 'list_channels':
        list_channels(params.get('category'))
    elif action == 'play':
        play_video(params.get('url'))

if __name__ == '__main__':
    router(sys.argv[2][1:])
