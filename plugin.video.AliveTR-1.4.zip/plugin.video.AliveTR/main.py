import sys
import re
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin

# Globale Addon-Konstanten sicher initialisieren
try:
    HANDLE = int(sys.argv[1])
    BASE_URL = sys.argv[0]
except (IndexError, ValueError):
    HANDLE = 0
    BASE_URL = ""

CATEGORIES = ["LiveTV", "KemalSunalFilmIzle", "BollywoodFilmIzle", "CocukFilmIzle"]
DEFAULT_UA = "Mozilla/5.0 (Android 17; Mobile; LG-M255; rv:153.0) Gecko/153.0 Firefox/153.0"

# Konfiguration: Ersetze diese URLs mit deinen echten M3U-Links
M3U_SOURCES = {
    "LiveTV": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/TurkTV.m3u",
    "KemalSunalFilmIzle": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/KemalSunal.m3u",
    "BollywoodFilmIzle": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/Bollywoodfilmizle.m3u",
    "CocukFilmIzle": "https://raw.githubusercontent.com/don24crk/Don24crk-Repository/refs/heads/master/Cocukfilmizle.m3u",
}

def log(message):
    xbmc.log(f"[AliveTR] {message}", xbmc.LOGINFO)

def fetch_m3u(url):
    """Lädt die M3U-Playlist und fängt 404-Fehler sowie Timeouts sauber ab."""
    headers = {"User-Agent": DEFAULT_UA}
    try:
        response = requests.get(url, headers=headers, timeout=15)
        if response.status_code == 404:
            log(f"Fehler 404: Playlist nicht gefunden unter {url}. Verzeichnis bleibt leer.")
            return ""
        response.raise_for_status()
        return response.text
    except Exception as e:
        log(f"Fehler beim Laden der Playlist ({url}): {str(e)}")
        return ""

def parse_m3u(data):
    """Parst die M3U-Daten und extrahiert Titel, Logos, Fanarts und spezifische User-Agents."""
    playlist_items = []
    if not data:
        return playlist_items
        
    lines = data.splitlines()
    current_item = {}
    current_ua = DEFAULT_UA

    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"):
            continue
            
        # BUGFIX: Holt das zweite Element (Index 1) der Liste und wendet .strip() an
        if line.startswith("#EXTVLCOPT:http-user-agent="):
            if "=" in line:
                current_ua = line.split("=", 1)[1].strip()
            continue
            
        # Parst die Metadaten der Kanalzeile
        if line.startswith("#EXTINF:"):
            current_item = {}
            tvg_logo_match = re.search(r'tvg-logo=["\'](.*?)["\']', line)
            fanart_match = re.search(r'fanart-image=["\'](.*?)["\']', line)
            
            if tvg_logo_match:
                current_item["logo"] = tvg_logo_match.group(1)
            if fanart_match:
                current_item["fanart"] = fanart_match.group(1)
                
            comma_idx = line.rfind(",")
            if comma_idx != -1:
                current_item["title"] = line[comma_idx + 1:].strip()
            else:
                current_item["title"] = "Unbekannter Stream"
                
        # Wenn die Zeile keine Raute hat, ist es die Stream-URL
        elif not line.startswith("#"):
            if current_item.get("title"):
                current_item["url"] = line
                current_item["ua"] = current_ua
                playlist_items.append(current_item)
                
                # Zurücksetzen für den nächsten Eintrag
                current_item = {}
                current_ua = DEFAULT_UA
                
    return playlist_items

def show_categories():
    """Erstellt das Hauptmenü mit den vier Kategorien."""
    for category in CATEGORIES:
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({"icon": "https://play-lh.googleusercontent.com/vddOJJ4od_aSnxc928y8YMFOSJ6I3G_GkbdyR19Sb-Sl1j-wvKv30C_3nN1OrR5yGUSIESh-0kM4bwIGSm0-xpQ=w600-h300-pc0xffffff-pd", "fanart": "https://i.pinimg.com/736x/33/01/c9/3301c9a82adac20eb33eef337b57562d.jpg"})
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(category)
        info_tag.setPlot(f"Durchsuche {category}")
        
        url = f"{BASE_URL}?mode=category&name={urllib.parse.quote_plus(category)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_channels(category_name):
    """Erstellt die Auswahlliste der Kanäle/Filme aus der M3U-Quelle."""
    m3u_url = M3U_SOURCES.get(category_name)
    if not m3u_url:
        return
        
    m3u_data = fetch_m3u(m3u_url)
    items = parse_m3u(m3u_data)
    
    # Inhalts-Typ festlegen, damit Kodi Lesezeichen/Fortsetzen-Datenbanken nutzt
    if "LiveTV" in category_name:
        xbmcplugin.setContent(HANDLE, "files")
    else:
        xbmcplugin.setContent(HANDLE, "movies")
    
    for item in items:
        stream_url = item["url"]
        title = item["title"]
        ua = item.get("ua", DEFAULT_UA)
        
        list_item = xbmcgui.ListItem(label=title)
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        
        # Aktiviert die Kodi-eigene Abspielkontrolle für Lesezeichen
        list_item.setProperty('IsPlayable', 'true')
        
        # Setzt Logos und Fanarts, falls in der M3U definiert
        if "logo" in item and item["logo"]:
            list_item.setArt({"thumb": item["logo"], "icon": item["logo"]})
        if "fanart" in item and item["fanart"]:
            list_item.setArt({"fanart": item["fanart"]})
            
        # Parameterübergabe für den internen Player-Modus
        query_params = {
            "mode": "play",
            "url": stream_url,
            "ua": ua
        }
        url = f"{BASE_URL}?{urllib.parse.urlencode(query_params)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_item(stream_url, ua):
    """Löst die finale URL für Kodi auf, lädt Inputstream und steuert das Abspielen."""
    list_item = xbmcgui.ListItem(path=stream_url)
    
    # 1. YouTube Integration Mapping
    if "youtube.com" in stream_url.lower() or "youtu.be" in stream_url.lower():
        yt_pattern = r"(?:v=|\/v\/|\/embed\/|\/shorts\/|youtu\.be\/|\/watch\?v=)([^#\&\?^\/]+)"
        yt_match = re.search(yt_pattern, stream_url)
        
        if yt_match:
            video_id = yt_match.group(1).strip()
            final_url = f"plugin://plugin.video.youtube/play/?video_id={video_id}"
            list_item.setPath(final_url)
        else:
            final_url = stream_url
            
    # 2. HLS / M3U8 Integration via inputstream.adaptive
    elif ".m3u8" in stream_url.lower() or "mode=hls" in stream_url.lower():
        final_url = stream_url
        list_item.setProperty("inputstream", "inputstream.adaptive")
        list_item.setProperty("inputstream.adaptive.manifest_type", "hls")
        list_item.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={urllib.parse.quote_plus(ua)}")
        if "|" not in final_url:
            final_url += f"|User-Agent={urllib.parse.quote_plus(ua)}"
        list_item.setPath(final_url)
            
    # 3. Standard HTTP Stream Wiedergabe
    else:
        final_url = stream_url
        if "|" not in final_url:
            final_url += f"|User-Agent={urllib.parse.quote_plus(ua)}"
        list_item.setPath(final_url)

    # Übergibt die aufgelöste URL an Kodi, um das Resume-Feature zu triggern
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)

def main():
    params = {}
    # BUGFIX: Sicheres Extrahieren des Query-Strings aus sys.argv (Index 2)
    if len(sys.argv) > 2 and sys.argv[2]:
        params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
        
    mode = params.get("mode")
    
    if not mode:
        show_categories()
    elif mode == "category":
        category_name = urllib.parse.unquote_plus(params.get("name", ""))
        show_channels(category_name)
    elif mode == "play":
        stream_url = urllib.parse.unquote_plus(params.get("url", ""))
        ua = urllib.parse.unquote_plus(params.get("ua", DEFAULT_UA))
        play_item(stream_url, ua)

if __name__ == "__main__":
    main()
