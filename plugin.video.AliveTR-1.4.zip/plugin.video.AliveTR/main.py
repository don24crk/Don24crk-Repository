import os
import sys
import re
import urllib.parse
import requests
import xbmc
import xbmcaddon
import xbmcvfs
import xbmcgui
import xbmcplugin

# Globale Addon-Konstanten sicher initialisieren
try:
    HANDLE = int(sys.argv[1])
    BASE_URL = sys.argv[0]
except (IndexError, ValueError):
    HANDLE = 0
    BASE_URL = ""

CATEGORIES = ["LiveTV", "KemalSunalFilmIzle", "BollywoodFilmIzle", "CocukFilmIzle"]
DEFAULT_UA = "Mozilla/5.0 (Android 17; Mobile; LG-M255; rv:153.0) Gecko/153.0 Firefox/153.0"

# BUGFIX: xbmcaddon wurde importiert, aber hier fehlte das Hauptobjekt
ADDON = xbmcaddon.Addon()
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))

# Die exakten Pfade zu Ihren Offline-M3U-Dateien
channels = {
    "LiveTV": os.path.join(ADDON_DIR, "resources", "TurkTV.m3u"),
    "KemalSunalFilmIzle": os.path.join(ADDON_DIR, "resources", "KemalSunal.m3u"),
    "BollywoodFilmIzle": os.path.join(ADDON_DIR, "resources", "Bollywoodfilmizle.m3u"),
    "CocukFilmIzle": os.path.join(ADDON_DIR, "resources", "Cocukfilmizle.m3u")
}

def log(message):
    xbmc.log(f"[AliveTR] {message}", xbmc.LOGINFO)

def lese_offline_m3u(kategorie):
    """Liest eine lokale M3U-Datei aus und gibt den Rohinhalt als Text zurück."""
    dateipfad = channels.get(kategorie)
    
    if not dateipfad or not xbmcvfs.exists(dateipfad):
        log(f"Datei nicht gefunden: {dateipfad}")
        return ""

    # Datei sicher über Kodis VFS öffnen und Inhalt einlesen
    with xbmcvfs.File(dateipfad, 'r') as f:
        inhalt = f.read()
        return inhalt

def parse_m3u(data):
    """Parst die M3U-Daten und extrahiert Titel, Logos, Fanarts und spezifische User-Agents."""
    playlist_items = []
    if not data:
        return playlist_items
        
    lines = data.splitlines()
    current_item = {}
    current_ua = DEFAULT_UA

    for line in lines:
        line = line.strip()
        if not line or line.startswith("#EXTM3U"):
            continue
            
        if line.startswith("#EXTVLCOPT:http-user-agent="):
            if "=" in line:
                current_ua = line.split("=", 1)[1].strip()
            continue
            
        if line.startswith("#EXTINF:"):
            current_item = {}
            tvg_logo_match = re.search(r'tvg-logo=["\'](.*?)["\']', line)
            fanart_match = re.search(r'fanart-image=["\'](.*?)["\']', line)
            
            if tvg_logo_match:
                current_item["logo"] = tvg_logo_match.group(1)
            if fanart_match:
                current_item["fanart"] = fanart_match.group(1)
                
            comma_idx = line.rfind(",")
            if comma_idx != -1:
                current_item["title"] = line[comma_idx + 1:].strip()
            else:
                current_item["title"] = "Unbekannter Stream"
                
        elif not line.startswith("#"):
            if current_item.get("title"):
                current_item["url"] = line
                current_item["ua"] = current_ua
                playlist_items.append(current_item)
                
                current_item = {}
                current_ua = DEFAULT_UA
                
    return playlist_items

def show_categories():
    """Erstellt das Hauptmenü mit den vier Kategorien."""
    for category in CATEGORIES:
        list_item = xbmcgui.ListItem(label=category)
        list_item.setArt({
    "icon": os.path.join(ADDON_DIR, "resources", "tvicontr.png"), 
    "fanart": os.path.join(ADDON_DIR, "resources", "turkflag.jpg")
})
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(category)
        info_tag.setPlot(f"Durchsuche {category}")
        
        url = f"{BASE_URL}?mode=category&name={urllib.parse.quote_plus(category)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_channels(category_name):
    """BUGFIX: Lädt Daten jetzt komplett lokal über die Funktion lese_offline_m3u."""
    m3u_data = lese_offline_m3u(category_name)
    items = parse_m3u(m3u_data)
    
    if "LiveTV" in category_name:
        xbmcplugin.setContent(HANDLE, "files")
    else:
        xbmcplugin.setContent(HANDLE, "movies")
    
    for item in items:
        stream_url = item["url"]
        title = item["title"]
        ua = item.get("ua", DEFAULT_UA)
        
        list_item = xbmcgui.ListItem(label=title)
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        
        list_item.setProperty('IsPlayable', 'true')
        
        if "logo" in item and item["logo"]:
            list_item.setArt({"thumb": item["logo"], "icon": item["logo"]})
        if "fanart" in item and item["fanart"]:
            list_item.setArt({"fanart": item["fanart"]})
            
        query_params = {
            "mode": "play",
            "url": stream_url,
            "ua": ua
        }
        url = f"{BASE_URL}?{urllib.parse.urlencode(query_params)}"
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(HANDLE)

def play_item(stream_url, ua):
    """Löst die finale URL auf und erzwingt inputstream.adaptive für M3U8/MPD."""
    list_item = xbmcgui.ListItem(path=stream_url)
    
    # Standard-Useragent für den Stream setzen
    list_item.setProperty("http-user-agent", ua)
    
    # 1. YouTube Integration
    if "youtube.com" in stream_url.lower() or "youtu.be" in stream_url.lower():
        yt_pattern = r"(?:v=|\/v\/|\/embed\/|\/shorts\/|youtu\.be\/|\/watch\?v=)([^#\&\?^\/]+)"
        yt_match = re.search(yt_pattern, stream_url)
        if yt_match:
            video_id = yt_match.group(1).strip()
            final_url = f"plugin://plugin.video.youtube/play/?video_id={video_id}"
            list_item.setPath(final_url)
            
    # 2. HLS Integration (.m3u8) via inputstream.adaptive
    elif ".m3u8" in stream_url.lower() or "mode=hls" in stream_url.lower():
        list_item.setProperty("inputstream", "inputstream.adaptive")
        list_item.setProperty("inputstream.adaptive.manifest_type", "hls")
        # Behebt Ladeprobleme bei manchen Live-Streams
        list_item.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={ua}")

    # 3. DASH Integration (.mpd) via inputstream.adaptive
    elif ".mpd" in stream_url.lower():
        list_item.setProperty("inputstream", "inputstream.adaptive")
        list_item.setProperty("inputstream.adaptive.manifest_type", "dash")
        list_item.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={ua}")

    # Video abspielen
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)


# Haupt-Routing für Kodi
if __name__ == "__main__":
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip('?')))
    mode = params.get("mode")
    name = params.get("name")
    url = params.get("url")
    user_agent = params.get("ua", DEFAULT_UA)

    if not mode:
        show_categories()
    elif mode == "category" and name:
        show_channels(name)
    elif mode == "play" and url:
        play_item(url, user_agent)

