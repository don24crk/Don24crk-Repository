﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X
	from urllib.request import urlopen  # Python 3.X

from .common import *


def mainMenu():
	addDir(translation(30621), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4fjztLkdMcfMVsbNfebkS7S'), 'extras': 'YT_FOLDER'}, tag='Galileo 360° Ganze Folgen')
	addDir(translation(30622), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4euZWxzBncPAYGHa9CeIoTd'), 'extras': 'YT_FOLDER'}, tag='Wissen für Youngsters | Galileo')
	addDir(translation(30623), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4eTR4SFQjDdhapk0yj4bD4I'), 'extras': 'YT_FOLDER'}, tag='Galileo testet Berufe | Galileo | ProSieben')
	addDir(translation(30624), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4cjffqQBBmzXYYg8JKUORVD'), 'extras': 'YT_FOLDER'}, tag='Galileo Essen | ProSieben')
	addDir(translation(30625), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4d4u9rmOuBxI7cojj4upzGI'), 'extras': 'YT_FOLDER'}, tag='Diese Woche bei Galileo')
	addDir(translation(30626), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4caotV6byTPOkGjY8u9ibHn'), 'extras': 'YT_FOLDER'}, tag='Galileo Wohnen')
	addDir(translation(30627), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4eYstD5IFaDqkJoN8hvTwJb'), 'extras': 'YT_FOLDER'}, tag='Die krassesten Schnäppchen | Galileo | ProSieben')
	addDir(translation(30628), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4eBiPZcledp_Kj5kXgFodMe'), 'extras': 'YT_FOLDER'}, tag='Bundestagswahl | ProSieben')
	addDir(translation(30629), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4fmHskIQVbZ7UUo-0OaS_L6'), 'extras': 'YT_FOLDER'}, tag='Alles rund um das Coronavirus!')
	addDir(translation(30630), icon, {'url': BASE_YT.format('PLg_KHB2Fiu4fowAy8_m8BGNlMYEpMc7t-'), 'extras': 'YT_FOLDER'}, tag='Lost Places - Vergessene Orte | Galileo | ProSieben')
	addDir(translation(30631), artpic+'livestream.png', {'mode': 'playLIVE', 'url': BASE_URL+'/GalileoLive.html'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE(url):
	live_url = False
	try:
		content = getUrl(url)
		stream = re.compile("const manifestUri =.*?'([^']+?)';", re.DOTALL).findall(content)[0]
		code = urlopen(stream, timeout=6).getcode()
		if str(code) == '200': live_url = stream
	except: pass
	if live_url:
		log("(navigator.playLIVE) ### LiveURL : {0} ###".format(live_url))
		listitem = xbmcgui.ListItem(path=live_url, label=translation(30641))
		listitem.setMimeType('application/x-mpegURL')
		if ADDON_operate('inputstream.adaptive') and 'm3u8' in live_url:
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
			listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
		xbmc.Player().play(item=live_url, listitem=listitem)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *weltderwunder.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE'), translation(30527), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def addDir(name, image, params={}, plot=None, tag=None, folder=True):
	if params.get('extras') == 'YT_FOLDER': u = params.get('url')
	else: u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Tagline': tag, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
