﻿# -*- coding: utf-8 -*-

import sys
import re
import xbmc
import xbmcgui
import xbmcplugin
PY2 = sys.version_info[0] == 2
if PY2:
	from urllib import urlencode  # Python 2.X
	from urllib2 import urlopen  # Python 2.X
else: 
	from urllib.parse import urlencode  # Python 3.X
	from urllib.request import urlopen  # Python 3.X

from .common import *


def mainMenu():
	addDir(translation(30621), icon, {'url': BASE_YT.format('UUBk6ZmyoyX1kLl-w17B0V1A'), 'extras': 'YT_FOLDER'}, tag='Welt der Wunder')
	addDir(translation(30622), icon, {'url': BASE_YT.format('PLYdG_9RWfsrVyu4ICw_oBdZfZj5fbEe5-'), 'extras': 'YT_FOLDER'}, tag='Wissensmagazin')
	addDir(translation(30623), icon, {'url': BASE_YT.format('PLYdG_9RWfsrV95xfifZQAPN5t2m3IhuHa'), 'extras': 'YT_FOLDER'}, tag='Technikmagazin')
	addDir(translation(30624), icon, {'url': BASE_YT.format('PLYdG_9RWfsrVOo69GoVCWRUqBr0O8IWnG'), 'extras': 'YT_FOLDER'}, tag='Genussmagazin')
	addDir(translation(30625), icon, {'url': BASE_YT.format('PLYdG_9RWfsrX205xRZvwSDOLVFmjYnGIM'), 'extras': 'YT_FOLDER'}, tag='Gesundheitsmagazin')
	addDir(translation(30626), icon, {'url': BASE_YT.format('PLYdG_9RWfsrWzJub6OF_j7eeMcvctTjfe'), 'extras': 'YT_FOLDER'}, tag='Wohnmagazin')
	addDir(translation(30627), icon, {'url': BASE_YT.format('PLYdG_9RWfsrXCehAv5GqyhI0QerT873Hk'), 'extras': 'YT_FOLDER'}, tag='Lifestylemagazin')
	addDir(translation(30628), icon, {'url': BASE_YT.format('PLYdG_9RWfsrXkIeFj3GNq-pb2aZdsz4tq'), 'extras': 'YT_FOLDER'}, tag='Gaming-Magazin')
	addDir(translation(30629), icon, {'url': BASE_YT.format('PLYdG_9RWfsrWmnIIGxb2JkKAFRJELRbWr'), 'extras': 'YT_FOLDER'}, tag='Magazin rund um Mobilität')
	addDir(translation(30630), icon, {'url': BASE_YT.format('PLYdG_9RWfsrWzx00mI0ydWP7pI751Arpe'), 'extras': 'YT_FOLDER'}, tag='Mysterymagazin')
	addDir(translation(30631), artpic+'livestream.png', {'mode': 'playLIVE', 'url': BASE_URL+'/master/WOW/WeltderWunder.html'}, folder=False)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def playLIVE(url):
	live_url = False
	try:
		content = getUrl(url)
		stream = re.compile("const manifestUri =.*?'([^']+?)';", re.DOTALL).findall(content)[0]
		code = urlopen(stream, timeout=6).getcode()
		if str(code) == '200': live_url = stream
	except: pass
	if live_url:
		log("(navigator.playLIVE) ### LiveURL : {0} ###".format(live_url))
		listitem = xbmcgui.ListItem(path=live_url, label=translation(30641))
		listitem.setMimeType('application/x-mpegURL')
		if ADDON_operate('inputstream.adaptive') and 'm3u8' in live_url:
			listitem.setProperty(INPUT_APP, 'inputstream.adaptive')
			listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
			listitem.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
		xbmc.Player().play(item=live_url, listitem=listitem)
	else:
		failing("(navigator.playLIVE) ##### Abspielen des Live-Streams NICHT möglich ##### URL : {0} #####\n   ########## KEINEN Live-Stream-Eintrag auf der Webseite von *weltderwunder.de* gefunden !!! ##########".format(url))
		return dialog.notification(translation(30521).format('LIVE'), translation(30527), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def addDir(name, image, params={}, plot=None, tag=None, folder=True):
	if params.get('extras') == 'YT_FOLDER': u = params.get('url')
	else: u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	liz.setInfo(type='Video', infoLabels={'Title': name, 'Tagline': tag, 'Plot': plot})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)
